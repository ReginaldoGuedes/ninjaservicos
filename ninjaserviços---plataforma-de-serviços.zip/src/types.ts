export type UserMode = 'client' | 'pro';

export type UrgencyLevel = 'urgente' | 'esta_semana' | 'proximos_15_dias' | 'apenas_orcamento';

export type OrderStatus = 'aberto' | 'em_negociacao' | 'fechado' | 'concluido' | 'cancelado';

export interface ServiceCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  subcategories: string[];
  popularTags: string[];
  averagePriceRange: string;
}

export interface ServiceOrder {
  id: string;
  title: string;
  category: string;
  subcategory: string;
  description: string;
  urgency: UrgencyLevel;
  location: {
    city: string;
    state: string;
    neighborhood: string;
    cep?: string;
  };
  clientName: string;
  clientPhone: string;
  clientAvatar?: string;
  createdAt: string;
  status: OrderStatus;
  estimatedBudget?: string;
  photos?: string[];
  unlockedByPros: string[]; // array of pro IDs who unlocked this lead
  maxUnlocks: number; // usually 4 in GetNinjas
  coinCost: number; // cost to unlock lead (e.g., 15-30 coins)
  acceptedQuoteId?: string;
  rating?: {
    stars: number;
    comment: string;
    createdAt: string;
  };
}

export interface Quote {
  id: string;
  orderId: string;
  proId: string;
  proName: string;
  proAvatar: string;
  proTitle: string;
  proRating: number;
  proReviewCount: number;
  price: number;
  priceUnit: 'total' | 'por_hora' | 'a_combinar';
  estimatedDays: string;
  message: string;
  createdAt: string;
  status: 'enviada' | 'aceita' | 'recusada';
}

export interface ProfessionalProfile {
  id: string;
  name: string;
  avatar: string;
  title: string;
  category: string;
  specialties: string[];
  bio: string;
  city: string;
  state: string;
  rating: number;
  reviewCount: number;
  completedJobsCount: number;
  coins: number;
  isVerified: boolean;
  phone: string;
  memberSince: string;
  responseTime: string;
}

export interface ChatMessage {
  id: string;
  orderId: string;
  senderId: string;
  senderName: string;
  senderRole: 'client' | 'pro';
  text: string;
  timestamp: string;
}

export interface CoinPackage {
  id: string;
  coins: number;
  bonus: number;
  price: number;
  popular?: boolean;
}

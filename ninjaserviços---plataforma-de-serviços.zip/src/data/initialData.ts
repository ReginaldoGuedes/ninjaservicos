import { ServiceOrder, ProfessionalProfile, Quote, ChatMessage } from '../types';

export const CURRENT_NINJA_PRO: ProfessionalProfile = {
  id: 'pro-carlos',
  name: 'Carlos Silveira',
  avatar: 'https://images.unsplash.com/photo-1540569014015-19a7be504e3a?auto=format&fit=crop&q=80&w=250',
  title: 'Eletricista Residencial e Instalador Certificado',
  category: 'reformas',
  specialties: ['Instalações Elétricas', 'Disjuntores', 'Ventilador de Teto', 'Troca de Fiação', 'Padrão Enel'],
  bio: 'Profissional com mais de 12 anos de experiência em reformas elétricas residenciais e comerciais em São Paulo. Certificado NR10, ferramentas de ponta e garantia de 6 meses em todos os serviços.',
  city: 'São Paulo',
  state: 'SP',
  rating: 4.9,
  reviewCount: 138,
  completedJobsCount: 247,
  coins: 25,
  isVerified: true,
  phone: '(11) 98452-1920',
  memberSince: 'Março de 2022',
  responseTime: 'Menos de 15 min'
};

export const OTHER_PROS: ProfessionalProfile[] = [
  {
    id: 'pro-mariana',
    name: 'Mariana Duarte',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=250',
    title: 'Especialista em Higienização e Diárias Residenciais',
    category: 'servicos_domesticos',
    specialties: ['Faxina Detalhada', 'Higienização de Sofás', 'Limpeza Pós-Obra', 'Organização de Armários'],
    bio: 'Atendo toda zona sul e oeste de SP. Levo produtos ecológicos profissionais de alta eficiência. Pontualidade britânica e referências verificadas.',
    city: 'São Paulo',
    state: 'SP',
    rating: 5.0,
    reviewCount: 94,
    completedJobsCount: 160,
    coins: 90,
    isVerified: true,
    phone: '(11) 97103-4412',
    memberSince: 'Janeiro de 2023',
    responseTime: 'Menos de 30 min'
  },
  {
    id: 'pro-rodrigo',
    name: 'Rodrigo Mendonça',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250',
    title: 'Técnico Especialista Apple e Notebooks',
    category: 'assistencia',
    specialties: ['Troca de Tela', 'Reparo em Placa', 'Troca de Bateria', 'Upgrade SSD / RAM'],
    bio: '10 anos de bancada. Atendimento delivery ou no laboratório. Peças originais e garantia formal por escrito de 90 dias.',
    city: 'São Paulo',
    state: 'SP',
    rating: 4.8,
    reviewCount: 215,
    completedJobsCount: 380,
    coins: 210,
    isVerified: true,
    phone: '(11) 99318-7744',
    memberSince: 'Novembro de 2021',
    responseTime: 'Instantâneo'
  },
  {
    id: 'pro-juliana',
    name: 'Juliana Camargo',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=250',
    title: 'Designer UI/UX e Desenvolvedora Web',
    category: 'tecnologia',
    specialties: ['Landing Pages', 'Identidade Visual', 'E-commerce', 'Sites Institucionais'],
    bio: 'Transformo pequenos e médios negócios em marcas atraentes na internet. Criação moderna, rápida e otimizada para mobile e SEO.',
    city: 'Campinas',
    state: 'SP',
    rating: 4.9,
    reviewCount: 76,
    completedJobsCount: 110,
    coins: 85,
    isVerified: true,
    phone: '(19) 98844-3321',
    memberSince: 'Agosto de 2023',
    responseTime: 'Menos de 1h'
  }
];

export const INITIAL_ORDERS: ServiceOrder[] = [
  {
    id: 'order-101',
    title: 'Instalação de 2 ventiladores de teto e troca de disjuntor geral',
    category: 'reformas',
    subcategory: 'Eletricista',
    description: 'Preciso instalar 2 ventiladores com controle de parede na sala e no quarto principal. Também preciso checar o quadro de luz pois o disjuntor principal está desarmando quando ligo o chuveiro e o forno.',
    urgency: 'urgente',
    location: {
      city: 'São Paulo',
      state: 'SP',
      neighborhood: 'Vila Mariana',
      cep: '04012-001'
    },
    clientName: 'Fernanda Albuquerque',
    clientPhone: '(11) 98123-9988',
    clientAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200',
    createdAt: 'Há 25 minutos',
    status: 'em_negociacao',
    estimatedBudget: 'R$ 280 a R$ 450',
    unlockedByPros: ['pro-carlos', 'pro-marcos-eletro'],
    maxUnlocks: 4,
    coinCost: 18,
    acceptedQuoteId: undefined
  },
  {
    id: 'order-102',
    title: 'Faxina completa pós-pintura em apartamento de 85m²',
    category: 'servicos_domesticos',
    subcategory: 'Faxina Pós-Obra',
    description: 'Acabei de pintar o apartamento de 3 dormitórios. Preciso de remoção de respingos de tinta do piso porcelanato, limpeza pesada dos vidros e banheiros.',
    urgency: 'esta_semana',
    location: {
      city: 'São Paulo',
      state: 'SP',
      neighborhood: 'Perdizes',
      cep: '05014-000'
    },
    clientName: 'Marcelo Penteado',
    clientPhone: '(11) 99876-1234',
    clientAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
    createdAt: 'Há 1 hora',
    status: 'em_negociacao',
    estimatedBudget: 'R$ 300 a R$ 500',
    unlockedByPros: ['pro-mariana'],
    maxUnlocks: 4,
    coinCost: 22
  },
  {
    id: 'order-103',
    title: 'Conserto de tela trincada iPhone 13 Pro Max',
    category: 'assistencia',
    subcategory: 'Conserto de Celular / Smartphone',
    description: 'O celular caiu da mesa e trincou o vidro frontal. O touch ainda funciona em partes mas a imagem está com linhas verticais. Gostaria de orçamento com peça original ou primeira linha.',
    urgency: 'urgente',
    location: {
      city: 'São Paulo',
      state: 'SP',
      neighborhood: 'Itaim Bibi',
      cep: '04533-000'
    },
    clientName: 'Lucas Barreto',
    clientPhone: '(11) 97722-5500',
    clientAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200',
    createdAt: 'Há 2 horas',
    status: 'em_negociacao',
    estimatedBudget: 'R$ 600 a R$ 1.100',
    unlockedByPros: ['pro-rodrigo'],
    maxUnlocks: 4,
    coinCost: 20
  },
  {
    id: 'order-104',
    title: 'Pintura interna de casa térrea (sala, 2 quartos e corredor)',
    category: 'reformas',
    subcategory: 'Pintor Residencial',
    description: 'Paredes já lixadas em bom estado. Só quero mudar a cor de branco para cinza claro fosco (tinta Suvinil já comprada por mim). Área aproximada de 140m² de parede.',
    urgency: 'proximos_15_dias',
    location: {
      city: 'São Paulo',
      state: 'SP',
      neighborhood: 'Santana',
      cep: '02012-010'
    },
    clientName: 'Beatriz Vasconcelos',
    clientPhone: '(11) 98311-6677',
    clientAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    createdAt: 'Há 3 horas',
    status: 'aberto',
    estimatedBudget: 'R$ 1.200 a R$ 2.000',
    unlockedByPros: [],
    maxUnlocks: 4,
    coinCost: 25
  },
  {
    id: 'order-105',
    title: 'Churrasqueiro para confraternização de família (35 pessoas)',
    category: 'eventos',
    subcategory: 'Churrasqueiro para Eventos',
    description: 'Evento no sábado das 12h às 18h no condomínio. Carnes e carvão serão providenciados por nós. Preciso de profissional experiente no preparo dos pontos da carne e auxílio no corte.',
    urgency: 'esta_semana',
    location: {
      city: 'São Paulo',
      state: 'SP',
      neighborhood: 'Moema',
      cep: '04515-030'
    },
    clientName: 'Renato Faria',
    clientPhone: '(11) 99188-4422',
    clientAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&q=80&w=200',
    createdAt: 'Há 4 horas',
    status: 'aberto',
    estimatedBudget: 'R$ 350 a R$ 550',
    unlockedByPros: [],
    maxUnlocks: 4,
    coinCost: 15
  },
  {
    id: 'order-106',
    title: 'Criação de site institucional com agendamento online para clínica',
    category: 'tecnologia',
    subcategory: 'Criação de Sites e Lojas Virtuais',
    description: 'Clínica de fisioterapia precisa de um site responsivo e moderno, com apresentação dos tratamentos, equipe médica e botão direto para WhatsApp e formulário de agendamento.',
    urgency: 'apenas_orcamento',
    location: {
      city: 'Campinas',
      state: 'SP',
      neighborhood: 'Cambuí',
      cep: '13024-000'
    },
    clientName: 'Dra. Camila Nogueira',
    clientPhone: '(19) 99201-1188',
    clientAvatar: 'https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?auto=format&fit=crop&q=80&w=200',
    createdAt: 'Há 5 horas',
    status: 'aberto',
    estimatedBudget: 'R$ 1.500 a R$ 3.200',
    unlockedByPros: [],
    maxUnlocks: 4,
    coinCost: 30
  }
];

export const INITIAL_QUOTES: Quote[] = [
  {
    id: 'quote-201',
    orderId: 'order-101',
    proId: 'pro-carlos',
    proName: 'Carlos Silveira',
    proAvatar: 'https://images.unsplash.com/photo-1540569014015-19a7be504e3a?auto=format&fit=crop&q=80&w=250',
    proTitle: 'Eletricista Residencial e Instalador Certificado',
    proRating: 4.9,
    proReviewCount: 138,
    price: 320,
    priceUnit: 'total',
    estimatedDays: 'Execução em 1 dia (amanhã à tarde)',
    message: 'Olá Fernanda! Faço a instalação dos 2 ventiladores com teste completo de balanceamento e verifico o disjuntor no mesmo atendimento. Se for apenas o dimensionamento do disjuntor, já faço a troca na hora. Dou garantia de 6 meses no serviço.',
    createdAt: 'Há 15 minutos',
    status: 'enviada'
  },
  {
    id: 'quote-202',
    orderId: 'order-101',
    proId: 'pro-marcos-eletro',
    proName: 'Marcos Santos Elétrica',
    proAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=250',
    proTitle: 'Técnico em Eletrotécnica CFT',
    proRating: 4.7,
    proReviewCount: 82,
    price: 350,
    priceUnit: 'total',
    estimatedDays: 'Atendimento hoje ou amanhã cedo',
    message: 'Boa tarde Fernanda! Estou próximo à Vila Mariana. Cobro R$ 350 com emissão de nota fiscal se precisar. Faço medição com amperímetro para garantir que o chuveiro não volte a desarmar.',
    createdAt: 'Há 8 minutos',
    status: 'enviada'
  },
  {
    id: 'quote-203',
    orderId: 'order-102',
    proId: 'pro-mariana',
    proName: 'Mariana Duarte',
    proAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=250',
    proTitle: 'Especialista em Higienização e Diárias Residenciais',
    proRating: 5.0,
    proReviewCount: 94,
    price: 380,
    priceUnit: 'total',
    estimatedDays: '1 dia inteiro com 2 profissionais',
    message: 'Olá Marcelo! Atendemos pós-obra com raspadores profissionais de borracha para não riscar o porcelanato e removedor de respingos sem cheiro tóxico. Deixamos o apto pronto para morar!',
    createdAt: 'Há 45 minutos',
    status: 'enviada'
  },
  {
    id: 'quote-204',
    orderId: 'order-103',
    proId: 'pro-rodrigo',
    proName: 'Rodrigo Mendonça',
    proAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250',
    proTitle: 'Técnico Especialista Apple e Notebooks',
    proRating: 4.8,
    proReviewCount: 215,
    price: 780,
    priceUnit: 'total',
    estimatedDays: 'Pronto em 2 horas (atendimento leva e traz)',
    message: 'Olá Lucas, tudo bem? Tenho a tela OLED original de reposição à pronta entrega. Troco e testo todos os sensores do FaceID. Acompanha película 3D de cortesia e garantia de 90 dias.',
    createdAt: 'Há 1 hora',
    status: 'enviada'
  }
];

export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'chat-1',
    orderId: 'order-101',
    senderId: 'client-me',
    senderName: 'Fernanda Albuquerque',
    senderRole: 'client',
    text: 'Olá Carlos! Vi que você enviou a proposta. Você conseguiria vir amanhã por volta das 14h?',
    timestamp: '14:20'
  },
  {
    id: 'chat-2',
    orderId: 'order-101',
    senderId: 'pro-carlos',
    senderName: 'Carlos Silveira',
    senderRole: 'pro',
    text: 'Olá Fernanda! Consigo sim, perfeito! Já reservo o horário das 14h na minha agenda. Os ventiladores já vieram com suporte?',
    timestamp: '14:22'
  },
  {
    id: 'chat-3',
    orderId: 'order-101',
    senderId: 'client-me',
    senderName: 'Fernanda Albuquerque',
    senderRole: 'client',
    text: 'Sim, as caixas estão lacradas com todos os suportes e ferragens que vieram de fábrica!',
    timestamp: '14:25'
  }
];

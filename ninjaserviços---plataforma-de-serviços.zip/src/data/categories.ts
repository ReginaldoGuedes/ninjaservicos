import { ServiceCategory, CoinPackage } from '../types';

export const SERVICE_CATEGORIES: ServiceCategory[] = [
  {
    id: 'reformas',
    name: 'Reformas e Reparos',
    description: 'Eletricistas, pedreiros, pintores, encanadores e montadores',
    icon: 'Hammer',
    color: 'bg-amber-50 text-amber-700 border-amber-200',
    subcategories: [
      'Pintor Residencial',
      'Eletricista',
      'Encanador / Desentupimento',
      'Pedreiro / Alvenaria',
      'Montador de Móveis',
      'Serralheiro',
      'Gesseiro',
      'Marceneiro'
    ],
    popularTags: ['Pintura', 'Fiação', 'Vazamento', 'Montar Guarda-roupa', 'Troca de Disjuntor'],
    averagePriceRange: 'R$ 150 a R$ 2.500'
  },
  {
    id: 'assistencia',
    name: 'Assistência Técnica',
    description: 'Celulares, notebooks, geladeiras, ar-condicionado e eletrodomésticos',
    icon: 'Wrench',
    color: 'bg-blue-50 text-blue-700 border-blue-200',
    subcategories: [
      'Conserto de Celular / Smartphone',
      'Notebook e Computador',
      'Ar-Condicionado (Instalação e Manutenção)',
      'Máquina de Lavar Roupa',
      'Geladeira e Freezer',
      'Televisão / Smart TV',
      'Micro-ondas e Fogão'
    ],
    popularTags: ['Troca de Tela', 'Limpeza Ar Split', 'Placa Mãe', 'Borracha Geladeira'],
    averagePriceRange: 'R$ 120 a R$ 800'
  },
  {
    id: 'servicos_domesticos',
    name: 'Serviços Domésticos',
    description: 'Diaristas, faxineiras, passadeiras e limpeza pós-obra',
    icon: 'Sparkles',
    color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    subcategories: [
      'Diarista Residencial',
      'Faxina Pós-Obra',
      'Passadeira de Roupas',
      'Limpeza de Estofados e Sofá',
      'Cozinheira / Personal Chef',
      'Piscineiro / Manutenção de Piscina',
      'Jardineiro'
    ],
    popularTags: ['Diária Completa', 'Higienização Sofá', 'Pós-Reforma', 'Corte de Grama'],
    averagePriceRange: 'R$ 160 a R$ 450'
  },
  {
    id: 'aulas',
    name: 'Aulas e Treinamentos',
    description: 'Inglês, reforço escolar, instrumentos musicais e personal trainer',
    icon: 'GraduationCap',
    color: 'bg-purple-50 text-purple-700 border-purple-200',
    subcategories: [
      'Aulas de Inglês',
      'Reforço Escolar (Matemática, Física)',
      'Personal Trainer',
      'Aulas de Violão e Guitarra',
      'Aulas de Piano e Teclado',
      'Aulas de Canto',
      'Preparatório para ENEM e Concursos'
    ],
    popularTags: ['Conversação', 'Emagrecimento', 'Violão Iniciante', 'Cálculo'],
    averagePriceRange: 'R$ 60 a R$ 150 / hora'
  },
  {
    id: 'eventos',
    name: 'Eventos e Festas',
    description: 'Buffet, churrasqueiros, garçons, fotógrafos e animação',
    icon: 'PartyPopper',
    color: 'bg-rose-50 text-rose-700 border-rose-200',
    subcategories: [
      'Churrasqueiro para Eventos',
      'Garçom e Copeira',
      'Bolo Decorado e Doces Finos',
      'Fotógrafo e Filmagem',
      'DJ com Som e Iluminação',
      'Bartender e Drinks',
      'Decoração de Festas'
    ],
    popularTags: ['Aniversário', 'Casamento', 'Churrasco 50 pessoas', 'Som e Luz'],
    averagePriceRange: 'R$ 300 a R$ 3.000'
  },
  {
    id: 'autos',
    name: 'Autos e Mecânica',
    description: 'Mecânico a domicílio, guincho, funilaria e estética automotiva',
    icon: 'Car',
    color: 'bg-orange-50 text-orange-700 border-orange-200',
    subcategories: [
      'Mecânico / Troca de Peças',
      'Guincho e Reboque 24h',
      'Martelinho de Ouro',
      'Polimento e Cristalização',
      'Higienização Interna Automotiva',
      'Auto Elétrica e Baterias',
      'Instalação de Som e Insulfilm'
    ],
    popularTags: ['Troca de Bateria', 'Guincho Urgente', 'Polimento', 'Freios'],
    averagePriceRange: 'R$ 150 a R$ 1.200'
  },
  {
    id: 'beleza',
    name: 'Saúde e Beleza',
    description: 'Manicure, maquiagem a domicílio, massoterapia e cabelo',
    icon: 'Scissors',
    color: 'bg-pink-50 text-pink-700 border-pink-200',
    subcategories: [
      'Manicure e Pedicure a Domicílio',
      'Maquiagem e Penteado para Noivas e Festas',
      'Massoterapia e Drenagem Linfática',
      'Design de Sobrancelhas e Cílios',
      'Corte e Escova de Cabelo',
      'Depilação'
    ],
    popularTags: ['Unha em Gel', 'Massagem Relaxante', 'Make Festa', 'Progressiva'],
    averagePriceRange: 'R$ 80 a R$ 400'
  },
  {
    id: 'tecnologia',
    name: 'Design e Tecnologia',
    description: 'Criação de sites, logotipos, edição de vídeo e suporte de TI',
    icon: 'Laptop',
    color: 'bg-cyan-50 text-cyan-700 border-cyan-200',
    subcategories: [
      'Criação de Sites e Lojas Virtuais',
      'Criação de Logotipo e Identidade Visual',
      'Edição de Vídeo para Redes Sociais',
      'Gestão de Tráfego Pago / Anúncios',
      'Suporte Técnico e Redes de Internet',
      'Desenvolvimento de Aplicativos'
    ],
    popularTags: ['Site WordPress', 'Logo Profissional', 'Reels / TikTok', 'Configurar Wi-Fi'],
    averagePriceRange: 'R$ 250 a R$ 4.500'
  }
];

export const COIN_PACKAGES: CoinPackage[] = [
  { id: 'pack-1', coins: 50, bonus: 0, price: 20.00 },
  { id: 'pack-2', coins: 120, bonus: 0, price: 50.00, popular: true },
  { id: 'pack-3', coins: 300, bonus: 0, price: 150.00 },
  { id: 'pack-4', coins: 600, bonus: 0, price: 300.00 },
];

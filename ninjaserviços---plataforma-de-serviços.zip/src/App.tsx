import React, { useState } from 'react';
import { NinjaProvider, useNinja } from './context/NinjaContext';
import { Navbar } from './components/Navbar';
import { ClientHome } from './components/ClientHome';
import { ClientOrdersView } from './components/ClientOrdersView';
import { ProMarketplaceView } from './components/ProMarketplaceView';
import { ProMyJobsView } from './components/ProMyJobsView';
import { ProProfileView } from './components/ProProfileView';
import { CreateOrderModal } from './components/CreateOrderModal';
import { ProQuoteModal } from './components/ProQuoteModal';
import { CoinRechargeModal } from './components/CoinRechargeModal';
import { ChatModal } from './components/ChatModal';
import { ReviewModal } from './components/ReviewModal';
import { ProRegisterModal } from './components/ProRegisterModal';
import { Footer } from './components/Footer';
import { ServiceOrder } from './types';

const MainApp: React.FC = () => {
  const { userMode, openChatForOrder, setUserMode } = useNinja();

  // Navigation tab state
  const [currentTab, setCurrentTab] = useState<string>('explore');

  // Modals state
  const [isCreateOrderOpen, setIsCreateOrderOpen] = useState<boolean>(false);
  const [preselectedCatId, setPreselectedCatId] = useState<string | undefined>(undefined);
  const [isCoinModalOpen, setIsCoinModalOpen] = useState<boolean>(false);
  const [isProRegisterOpen, setIsProRegisterOpen] = useState<boolean>(false);
  const [orderForQuote, setOrderForQuote] = useState<ServiceOrder | null>(null);
  const [reviewOrderId, setReviewOrderId] = useState<string | null>(null);

  const handleOpenCreateOrder = (catId?: string) => {
    setPreselectedCatId(catId);
    setIsCreateOrderOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 text-gray-900 selection:bg-blue-600 selection:text-white">
      {/* Navigation Bar with Mode Switcher */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        openCreateOrderModal={() => handleOpenCreateOrder()}
        openCoinModal={() => setIsCoinModalOpen(true)}
        openProRegisterModal={() => setIsProRegisterOpen(true)}
      />

      {/* Main Content View based on User Mode & Active Tab */}
      <main className="flex-1">
        {userMode === 'client' ? (
          <>
            {currentTab === 'explore' && (
              <ClientHome
                onOpenCreateOrder={handleOpenCreateOrder}
                onNavigateToOrders={() => setCurrentTab('my_orders')}
              />
            )}
            {currentTab === 'my_orders' && (
              <ClientOrdersView
                onOpenCreateOrder={() => handleOpenCreateOrder()}
                onOpenReviewModal={(orderId) => setReviewOrderId(orderId)}
              />
            )}
          </>
        ) : (
          <>
            {currentTab === 'marketplace' && (
              <ProMarketplaceView
                onOpenQuoteModal={(order) => setOrderForQuote(order)}
                onOpenCoinModal={() => setIsCoinModalOpen(true)}
                onOpenChat={(orderId) => openChatForOrder(orderId)}
                onOpenProRegister={() => setIsProRegisterOpen(true)}
              />
            )}
            {currentTab === 'pro_jobs' && (
              <ProMyJobsView
                onOpenQuoteModal={(order) => setOrderForQuote(order)}
                onOpenChat={(orderId) => openChatForOrder(orderId)}
                onNavigateToMarketplace={() => setCurrentTab('marketplace')}
              />
            )}
            {currentTab === 'pro_profile' && (
              <ProProfileView
                onOpenCoinModal={() => setIsCoinModalOpen(true)}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        onSelectCategory={(catId) => {
          if (userMode === 'client') {
            setCurrentTab('explore');
            handleOpenCreateOrder(catId);
          } else {
            setCurrentTab('marketplace');
          }
        }}
      />

      {/* Modals */}
      <CreateOrderModal
        isOpen={isCreateOrderOpen}
        onClose={() => setIsCreateOrderOpen(false)}
        preselectedCategoryId={preselectedCatId}
        onOrderCreated={() => {
          setCurrentTab('my_orders');
        }}
      />

      <ProQuoteModal
        order={orderForQuote}
        onClose={() => setOrderForQuote(null)}
      />

      <CoinRechargeModal
        isOpen={isCoinModalOpen}
        onClose={() => setIsCoinModalOpen(false)}
      />

      <ChatModal />

      <ReviewModal
        orderId={reviewOrderId}
        onClose={() => setReviewOrderId(null)}
      />

      <ProRegisterModal
        isOpen={isProRegisterOpen}
        onClose={() => setIsProRegisterOpen(false)}
        onSuccess={() => {
          setUserMode('pro');
          setCurrentTab('marketplace');
        }}
      />
    </div>
  );
};

export default function App() {
  return (
    <NinjaProvider>
      <MainApp />
    </NinjaProvider>
  );
}

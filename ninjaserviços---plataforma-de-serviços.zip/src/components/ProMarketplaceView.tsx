import React, { useState } from 'react';
import { useNinja } from '../context/NinjaContext';
import { ServiceOrder } from '../types';
import { SERVICE_CATEGORIES } from '../data/categories';
import {
  Coins,
  Search,
  Filter,
  MapPin,
  Clock,
  Unlock,
  CheckCircle,
  MessageSquare,
  AlertCircle,
  Send,
  Zap,
  Phone,
  ShieldCheck,
  Plus,
  Sparkles,
  QrCode
} from 'lucide-react';

interface ProMarketplaceViewProps {
  onOpenQuoteModal: (order: ServiceOrder) => void;
  onOpenCoinModal: () => void;
  onOpenChat: (orderId: string) => void;
  onOpenProRegister?: () => void;
}

export const ProMarketplaceView: React.FC<ProMarketplaceViewProps> = ({
  onOpenQuoteModal,
  onOpenCoinModal,
  onOpenChat,
  onOpenProRegister
}) => {
  const {
    orders,
    quotes,
    currentPro,
    unlockLead
  } = useNinja();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [urgencyFilter, setUrgencyFilter] = useState<string>('all');
  const [onlyUnlocked, setOnlyUnlocked] = useState<boolean>(false);
  const [actionFeedback, setActionFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const handleUnlockLead = (orderId: string) => {
    const res = unlockLead(orderId);
    if (res.success) {
      setActionFeedback({ type: 'success', message: res.message });
    } else {
      setActionFeedback({ type: 'error', message: res.message });
    }
    setTimeout(() => setActionFeedback(null), 3500);
  };

  const filteredOrders = orders.filter(order => {
    if (selectedCategory !== 'all' && order.category !== selectedCategory) return false;
    if (urgencyFilter !== 'all' && order.urgency !== urgencyFilter) return false;
    if (onlyUnlocked && !order.unlockedByPros.includes(currentPro.id)) return false;

    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      order.title.toLowerCase().includes(q) ||
      order.description.toLowerCase().includes(q) ||
      order.subcategory.toLowerCase().includes(q) ||
      order.location.neighborhood.toLowerCase().includes(q) ||
      order.location.city.toLowerCase().includes(q)
    );
  });

  const myUnlockedCount = orders.filter(o => o.unlockedByPros.includes(currentPro.id)).length;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* PRO HERO / STATS HEADER */}
      <div className="bg-white border border-gray-200 rounded-2xl p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          
          {/* Pro info */}
          <div className="flex items-center gap-4">
            <img
              src={currentPro.avatar}
              alt={currentPro.name}
              referrerPolicy="no-referrer"
              className="w-16 h-16 rounded-full object-cover border border-gray-200 shadow-xs shrink-0"
            />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-extrabold text-gray-900">
                  Olá, {currentPro.name}!
                </h1>
                <span className="bg-blue-50 text-blue-700 border border-blue-100 text-[10px] font-semibold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-blue-600" />
                  Ninja Verificado
                </span>
              </div>
              <p className="text-xs sm:text-sm text-gray-500 mt-0.5">
                {currentPro.title} • {currentPro.city}, {currentPro.state}
              </p>
              <div className="flex items-center gap-3 text-xs text-gray-500 mt-1">
                <span className="font-semibold text-gray-700">⭐ {currentPro.rating} ({currentPro.reviewCount} avaliações)</span>
                <span className="text-gray-300">•</span>
                <span>{currentPro.completedJobsCount} serviços realizados</span>
              </div>
            </div>
          </div>

          {/* Coins Balance Box */}
          <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex items-center gap-4 shrink-0 w-full sm:w-auto justify-between sm:justify-start">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-yellow-100 text-yellow-800 flex items-center justify-center font-bold">
                <Coins className="w-6 h-6 fill-yellow-500 text-yellow-800" />
              </div>
              <div>
                <span className="text-[10px] text-gray-400 font-bold block uppercase tracking-wider">
                  Saldo de Moedas
                </span>
                <span className="text-2xl font-extrabold text-gray-900">
                  {currentPro.coins} <span className="text-xs text-gray-500 font-normal">moedas</span>
                </span>
              </div>
            </div>

            <button
              onClick={onOpenCoinModal}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs px-4 py-2.5 rounded-full shadow-xs transition-colors flex items-center gap-1.5 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Recarregar</span>
            </button>
          </div>

        </div>

        {/* Quick hint banner */}
        <div className="mt-6 pt-4 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3 text-xs text-gray-500">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-yellow-500 fill-yellow-500" />
            <span>Regra Ninja: Cada pedido aceita no máximo 4 profissionais. Desbloqueie contatos cedo para aumentar suas chances!</span>
          </div>
          <div className="font-semibold text-gray-700">
            {myUnlockedCount} contatos liberados na sua conta
          </div>
        </div>
      </div>

      {/* WELCOME BONUS CALLOUT & PIX INFO BANNER */}
      <div className="bg-gradient-to-r from-blue-50/90 via-indigo-50/70 to-blue-50/90 border border-blue-200/80 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Sparkles className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase text-blue-900 tracking-wider">
                Bônus de Boas-Vindas & Pacotes Pix
              </span>
              <span className="bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full">
                25 Moedas Grátis no Cadastro
              </span>
            </div>
            <p className="text-xs text-blue-800 mt-1 leading-relaxed">
              Você ganha <strong>25 moedas gratuitas</strong> no cadastro para liberar e fechar <strong>1 negociação de teste</strong>. Após utilizá-las, continue desbloqueando clientes comprando pacotes via Pix: <strong>50 moedas por R$ 20</strong>, <strong>120 moedas por R$ 50</strong>, <strong>300 moedas por R$ 150</strong> ou <strong>600 moedas por R$ 300</strong>!
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end md:self-center shrink-0">
          {onOpenProRegister && (
            <button
              type="button"
              onClick={onOpenProRegister}
              className="text-xs font-bold text-blue-700 hover:text-blue-900 px-3 py-2 rounded-full border border-blue-300 hover:bg-blue-100/60 transition-colors"
            >
              Novo Cadastro
            </button>
          )}
          <button
            type="button"
            onClick={onOpenCoinModal}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-full shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Ver Pacotes Pix</span>
          </button>
        </div>
      </div>

      {/* Global Feedback Banner */}
      {actionFeedback && (
        <div
          className={`p-4 rounded-xl border text-xs sm:text-sm font-semibold flex items-center justify-between ${
            actionFeedback.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {actionFeedback.type === 'success' ? (
              <CheckCircle className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600" />
            )}
            <span>{actionFeedback.message}</span>
          </div>
          {actionFeedback.type === 'error' && (
            <button
              onClick={onOpenCoinModal}
              className="underline text-rose-900 font-bold ml-2"
            >
              Comprar Moedas agora
            </button>
          )}
        </div>
      )}

      {/* SEARCH AND FILTERS */}
      <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search Input */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Buscar por serviço, bairro ou descrição (ex: chuveiro, pintura, moema...)"
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-gray-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white transition-colors"
            />
          </div>

          {/* Category dropdown */}
          <select
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="w-full sm:w-48 px-3 py-2 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50"
          >
            <option value="all">Todas Categorias</option>
            {SERVICE_CATEGORIES.map(cat => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>

          {/* Urgency dropdown */}
          <select
            value={urgencyFilter}
            onChange={e => setUrgencyFilter(e.target.value)}
            className="w-full sm:w-44 px-3 py-2 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50"
          >
            <option value="all">Todas Urgências</option>
            <option value="urgente">🚨 Urgente</option>
            <option value="esta_semana">📅 Esta semana</option>
            <option value="proximos_15_dias">🗓️ 15 dias</option>
            <option value="apenas_orcamento">🔍 Pesquisando</option>
          </select>
        </div>

        {/* Quick filter checkboxes */}
        <div className="flex items-center justify-between pt-2 border-t border-gray-100 text-xs">
          <label className="flex items-center gap-2 cursor-pointer text-gray-600 hover:text-gray-900 select-none">
            <input
              type="checkbox"
              checked={onlyUnlocked}
              onChange={e => setOnlyUnlocked(e.target.checked)}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span>Mostrar apenas contatos que eu já liberei</span>
          </label>

          <span className="text-gray-400 font-medium">
            {filteredOrders.length} pedidos disponíveis
          </span>
        </div>
      </div>

      {/* LEADS MURAL GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredOrders.map(order => {
          const isUnlocked = order.unlockedByPros.includes(currentPro.id);
          const slotsLeft = order.maxUnlocks - order.unlockedByPros.length;
          const myQuote = quotes.find(q => q.orderId === order.id && q.proId === currentPro.id);
          const isFull = slotsLeft <= 0 && !isUnlocked;

          return (
            <div
              key={order.id}
              className={`rounded-2xl border transition-all flex flex-col justify-between overflow-hidden shadow-xs hover:border-gray-300 ${
                isUnlocked
                  ? 'bg-blue-50/20 border-blue-200'
                  : 'bg-white border-gray-200'
              }`}
            >
              {/* Card Top */}
              <div className="p-5">
                
                {/* Header tags */}
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-100 px-2.5 py-0.5 rounded-full">
                      {order.subcategory}
                    </span>
                    {order.urgency === 'urgente' && (
                      <span className="text-[10px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                        <Clock className="w-3 h-3" /> Urgente
                      </span>
                    )}
                  </div>

                  <span className="text-[11px] text-gray-400">{order.createdAt}</span>
                </div>

                {/* Title */}
                <h3 className="text-base font-bold text-gray-900 mb-2 line-clamp-2">
                  {order.title}
                </h3>

                {/* Description */}
                <p className="text-xs text-gray-600 line-clamp-3 mb-4 leading-relaxed">
                  {order.description}
                </p>

                {/* Location & Client Estimate */}
                <div className="space-y-1.5 text-xs text-gray-500 pt-3 border-t border-gray-100">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-gray-400" />
                      <span>{order.location.neighborhood}, {order.location.city} - {order.location.state}</span>
                    </div>
                    <span className="text-[11px] text-gray-400">~ 3.5 km</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-gray-500">Estimativa do cliente:</span>
                    <span className="font-bold text-gray-800">{order.estimatedBudget || 'Sob consulta'}</span>
                  </div>
                </div>

                {/* Unlocked Contact Details (if unlocked) */}
                {isUnlocked && (
                  <div className="mt-4 p-3 bg-white rounded-xl border border-blue-200 shadow-xs space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-gray-900">
                        Cliente: {order.clientName}
                      </span>
                      <span className="text-[11px] text-emerald-700 font-semibold bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" /> Contato Liberado
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-blue-700 font-bold">
                      <Phone className="w-3.5 h-3.5" />
                      <span>{order.clientPhone}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Card Footer Actions */}
              <div className="px-5 py-3.5 bg-gray-50 border-t border-gray-100 flex items-center justify-between gap-3">
                {/* Slots info */}
                <div className="text-xs">
                  <div className="flex items-center gap-1 font-semibold text-gray-700">
                    <span className="w-2 h-2 rounded-full bg-yellow-500" />
                    <span>{slotsLeft} de {order.maxUnlocks} vagas restantes</span>
                  </div>
                  {!isUnlocked && (
                    <span className="text-[11px] text-gray-400">
                      Custo: <strong className="text-yellow-700 font-bold">{order.coinCost} Moedas</strong>
                    </span>
                  )}
                </div>

                {/* Button Action */}
                <div>
                  {isUnlocked ? (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onOpenChat(order.id)}
                        className="px-3.5 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-full text-xs font-semibold flex items-center gap-1 transition-colors"
                        title="Abrir conversa no chat"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
                        <span>Chat</span>
                      </button>

                      {myQuote ? (
                        <div className="text-right">
                          <span className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold px-3 py-2 rounded-full flex items-center gap-1">
                            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                            R$ {myQuote.price}
                          </span>
                        </div>
                      ) : (
                        <button
                          onClick={() => onOpenQuoteModal(order)}
                          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Enviar Orçamento</span>
                        </button>
                      )}
                    </div>
                  ) : isFull ? (
                    <span className="text-xs font-semibold text-gray-400 bg-gray-200 px-3.5 py-2 rounded-full cursor-not-allowed">
                      Vagas Esgotadas (4/4)
                    </span>
                  ) : (
                    <button
                      onClick={() => handleUnlockLead(order.id)}
                      className="px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-gray-950 font-semibold text-xs rounded-full shadow-xs flex items-center gap-1.5 transition-colors"
                    >
                      <Unlock className="w-3.5 h-3.5" />
                      <span>Liberar ({order.coinCost} Moedas)</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredOrders.length === 0 && (
        <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center space-y-3 shadow-xs">
          <p className="text-gray-500 text-sm">
            Nenhum pedido encontrado com os filtros selecionados.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
              setUrgencyFilter('all');
              setOnlyUnlocked(false);
            }}
            className="text-xs font-semibold text-blue-600 hover:underline"
          >
            Limpar todos os filtros
          </button>
        </div>
      )}

    </div>
  );
};

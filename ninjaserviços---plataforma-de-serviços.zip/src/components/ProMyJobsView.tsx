import React, { useState } from 'react';
import { useNinja } from '../context/NinjaContext';
import { ServiceOrder } from '../types';
import {
  Phone,
  MessageSquare,
  MapPin,
  CheckCircle,
  Calendar,
  Send,
  AlertCircle,
  Clock,
  Check
} from 'lucide-react';

interface ProMyJobsViewProps {
  onOpenQuoteModal: (order: ServiceOrder) => void;
  onOpenChat: (orderId: string) => void;
  onNavigateToMarketplace: () => void;
}

export const ProMyJobsView: React.FC<ProMyJobsViewProps> = ({
  onOpenQuoteModal,
  onOpenChat,
  onNavigateToMarketplace
}) => {
  const {
    orders,
    quotes,
    currentPro,
    completeOrder
  } = useNinja();

  const [filter, setFilter] = useState<'all' | 'negociando' | 'fechados'>('all');

  // Orders unlocked by current pro
  const myUnlockedOrders = orders.filter(o => o.unlockedByPros.includes(currentPro.id));

  const filtered = myUnlockedOrders.filter(order => {
    const myQuote = quotes.find(q => q.orderId === order.id && q.proId === currentPro.id);
    const isWon = order.acceptedQuoteId === myQuote?.id || myQuote?.status === 'aceita';

    if (filter === 'negociando') return !isWon && order.status !== 'concluido';
    if (filter === 'fechados') return isWon || order.status === 'concluido';
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-gray-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">
            Meus Atendimentos
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Clientes cujos contatos você liberou. Negocie pelo chat, ligue diretamente e feche orçamentos.
          </p>
        </div>

        <button
          onClick={onNavigateToMarketplace}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm px-4 py-2.5 rounded-full shadow-xs transition-colors shrink-0 self-start sm:self-auto"
        >
          Buscar Novos Pedidos
        </button>
      </div>

      {/* Filter tabs */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-colors ${
            filter === 'all'
              ? 'bg-gray-900 text-white'
              : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
          }`}
        >
          Todos ({myUnlockedOrders.length})
        </button>
        <button
          onClick={() => setFilter('negociando')}
          className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-colors ${
            filter === 'negociando'
              ? 'bg-gray-900 text-white'
              : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
          }`}
        >
          Em Negociação
        </button>
        <button
          onClick={() => setFilter('fechados')}
          className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-colors ${
            filter === 'fechados'
              ? 'bg-gray-900 text-white'
              : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
          }`}
        >
          Fechados / Concluídos
        </button>
      </div>

      {/* Empty state */}
      {filtered.length === 0 && (
        <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center space-y-4 shadow-xs">
          <div className="w-14 h-14 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
            <AlertCircle className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-gray-900">
            Nenhum atendimento encontrado
          </h3>
          <p className="text-xs sm:text-sm text-gray-500 max-w-md mx-auto">
            Você ainda não liberou contatos nesta seção. Visite o Mural de Pedidos e use suas moedas para desbloquear clientes!
          </p>
          <button
            onClick={onNavigateToMarketplace}
            className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm px-5 py-2.5 rounded-full shadow-xs transition-colors"
          >
            Ver Pedidos Disponíveis
          </button>
        </div>
      )}

      {/* Orders List */}
      <div className="space-y-4">
        {filtered.map(order => {
          const myQuote = quotes.find(q => q.orderId === order.id && q.proId === currentPro.id);
          const isWon = order.acceptedQuoteId === myQuote?.id || myQuote?.status === 'aceita';

          return (
            <div
              key={order.id}
              className={`bg-white rounded-2xl border p-5 sm:p-6 shadow-xs hover:border-gray-300 transition-all ${
                isWon ? 'border-emerald-300 ring-2 ring-emerald-500/10' : 'border-gray-200'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                
                {/* Left side info */}
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-100 px-2.5 py-0.5 rounded-full">
                      {order.subcategory}
                    </span>
                    {isWon ? (
                      <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <Check className="w-3 h-3" /> Orçamento Fechado!
                      </span>
                    ) : (
                      <span className="text-xs font-semibold text-yellow-800 bg-yellow-50 border border-yellow-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Em Negociação
                      </span>
                    )}
                    <span className="text-xs text-gray-400">{order.createdAt}</span>
                  </div>

                  <h3 className="text-lg font-bold text-gray-900">
                    {order.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-gray-600 line-clamp-2 leading-relaxed">
                    {order.description}
                  </p>

                  <div className="flex items-center gap-1 text-xs text-gray-500 pt-1">
                    <MapPin className="w-3.5 h-3.5 text-gray-400" />
                    <span>{order.location.neighborhood}, {order.location.city} - {order.location.state}</span>
                  </div>
                </div>

                {/* Client Contact Details Box */}
                <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 shrink-0 w-full sm:w-64 space-y-2">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                    Dados do Cliente
                  </span>
                  <div className="flex items-center gap-2.5">
                    <img
                      src={order.clientAvatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200'}
                      alt={order.clientName}
                      referrerPolicy="no-referrer"
                      className="w-9 h-9 rounded-full object-cover border border-gray-200 shrink-0"
                    />
                    <div>
                      <h4 className="text-xs font-bold text-gray-900">{order.clientName}</h4>
                      <a
                        href={`tel:${order.clientPhone}`}
                        className="text-xs font-semibold text-blue-600 hover:underline flex items-center gap-1 mt-0.5"
                      >
                        <Phone className="w-3 h-3" />
                        {order.clientPhone}
                      </a>
                    </div>
                  </div>
                </div>

              </div>

              {/* My proposal details & actions */}
              <div className="mt-5 pt-4 border-t border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                {myQuote ? (
                  <div className="flex items-center gap-4 text-xs">
                    <div>
                      <span className="text-gray-400 block text-[10px]">Sua proposta enviada:</span>
                      <span className="text-base font-extrabold text-gray-900">
                        R$ {myQuote.price} <span className="text-xs font-normal text-gray-500">({myQuote.priceUnit})</span>
                      </span>
                    </div>
                    <div className="text-gray-500 border-l border-gray-200 pl-3">
                      <span className="text-gray-400 block text-[10px]">Prazo informado:</span>
                      <span className="font-semibold text-gray-700">{myQuote.estimatedDays}</span>
                    </div>
                  </div>
                ) : (
                  <div className="text-xs text-yellow-800 font-medium flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 text-yellow-600" />
                    <span>Contato liberado! Você ainda não enviou uma proposta formal.</span>
                  </div>
                )}

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    onClick={() => onOpenChat(order.id)}
                    className="px-4 py-2 bg-gray-900 hover:bg-gray-800 text-white rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-blue-400" />
                    <span>Abrir Chat</span>
                  </button>

                  {!myQuote && (
                    <button
                      onClick={() => onOpenQuoteModal(order)}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Enviar Orçamento</span>
                    </button>
                  )}

                  {isWon && order.status !== 'concluido' && (
                    <button
                      onClick={() => completeOrder(order.id)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Marcar como Concluído</span>
                    </button>
                  )}
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};

import React, { useState } from 'react';
import { useNinja } from '../context/NinjaContext';
import { ServiceOrder, Quote } from '../types';
import {
  Clock,
  MapPin,
  MessageSquare,
  CheckCircle,
  AlertCircle,
  Star,
  Check,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  PlusCircle,
  PhoneCall,
  Calendar
} from 'lucide-react';

interface ClientOrdersViewProps {
  onOpenCreateOrder: () => void;
  onOpenReviewModal: (orderId: string) => void;
}

export const ClientOrdersView: React.FC<ClientOrdersViewProps> = ({
  onOpenCreateOrder,
  onOpenReviewModal
}) => {
  const {
    orders,
    quotes,
    clientProfile,
    acceptQuote,
    completeOrder,
    openChatForOrder
  } = useNinja();

  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Orders created by or assigned to current client
  const myOrders = orders.filter(
    o => o.clientName === clientProfile.name || o.id === 'order-101'
  );

  const filteredOrders = myOrders.filter(o => {
    if (filterStatus === 'all') return true;
    return o.status === filterStatus;
  });

  const getStatusBadge = (status: ServiceOrder['status']) => {
    switch (status) {
      case 'aberto':
        return (
          <span className="bg-amber-50 text-amber-700 border border-amber-200/60 text-xs font-semibold px-2.5 py-1 rounded-full flex items-center gap-1">
            <Clock className="w-3 h-3" /> Aguardando Ninjas
          </span>
        );
      case 'em_negociacao':
        return (
          <span className="bg-blue-50 text-blue-700 border border-blue-200/60 text-xs font-semibold px-2.5 py-1 rounded-full flex items-center gap-1">
            <MessageSquare className="w-3 h-3" /> Em Negociação
          </span>
        );
      case 'fechado':
        return (
          <span className="bg-purple-50 text-purple-700 border border-purple-200/60 text-xs font-semibold px-2.5 py-1 rounded-full flex items-center gap-1">
            <Check className="w-3 h-3" /> Orçamento Aceito
          </span>
        );
      case 'concluido':
        return (
          <span className="bg-emerald-50 text-emerald-700 border border-emerald-200/60 text-xs font-semibold px-2.5 py-1 rounded-full flex items-center gap-1">
            <CheckCircle className="w-3 h-3" /> Concluído
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-gray-200">
        <div>
          <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-1">
            Painel do Solicitante
          </h3>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">
            Meus Pedidos de Serviço
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Acompanhe propostas recebidas, converse com profissionais e gerencie seus orçamentos.
          </p>
        </div>

        <button
          onClick={onOpenCreateOrder}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm px-5 py-2.5 rounded-full shadow-xs flex items-center gap-1.5 transition-colors shrink-0 self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Novo Pedido</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'all', label: 'Todos os Pedidos' },
          { id: 'em_negociacao', label: 'Em Negociação' },
          { id: 'fechado', label: 'Fechados' },
          { id: 'concluido', label: 'Concluídos' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setFilterStatus(tab.id)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
              filterStatus === tab.id
                ? 'bg-gray-900 text-white shadow-xs'
                : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Empty State */}
      {filteredOrders.length === 0 && (
        <div className="bg-white rounded-2xl border border-gray-200 p-12 text-center space-y-4 shadow-xs">
          <div className="w-14 h-14 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
            <AlertCircle className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-gray-900">
            Nenhum pedido encontrado nesta categoria
          </h3>
          <p className="text-xs sm:text-sm text-gray-500 max-w-md mx-auto">
            Você ainda não tem pedidos com esse status. Peça um orçamento grátis agora mesmo e receba até 4 propostas!
          </p>
          <button
            onClick={onOpenCreateOrder}
            className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm px-6 py-2.5 rounded-full shadow-xs transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            Pedir Orçamento Grátis
          </button>
        </div>
      )}

      {/* Orders List */}
      <div className="space-y-5">
        {filteredOrders.map(order => {
          const orderQuotes = quotes.filter(q => q.orderId === order.id);
          const isExpanded = expandedOrderId === order.id || orderQuotes.length > 0;
          const acceptedQuote = orderQuotes.find(q => q.id === order.acceptedQuoteId || q.status === 'aceita');

          return (
            <div
              key={order.id}
              className="bg-white rounded-2xl border border-gray-200 shadow-xs hover:border-gray-300 transition-colors overflow-hidden"
            >
              {/* Order Header Summary */}
              <div className="p-5 sm:p-6">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-100 px-2.5 py-1 rounded-full">
                      {order.subcategory}
                    </span>
                    <span className="text-xs text-gray-400">Criado {order.createdAt}</span>
                  </div>
                  {getStatusBadge(order.status)}
                </div>

                <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-2">
                  {order.title}
                </h2>

                <p className="text-xs sm:text-sm text-gray-600 mb-4 leading-relaxed">
                  {order.description}
                </p>

                {/* Location & slots info */}
                <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-gray-500 pt-3 border-t border-gray-100">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span>{order.location.neighborhood}, {order.location.city} - {order.location.state}</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-semibold text-gray-700">
                      Estimativa: {order.estimatedBudget || 'Sob consulta'}
                    </span>
                    <span className="bg-gray-100 text-gray-700 font-semibold px-2.5 py-0.5 rounded-full text-[11px]">
                      {order.unlockedByPros.length}/{order.maxUnlocks} vagas de Ninjas
                    </span>
                  </div>
                </div>

                {/* Complete / Rate button if status is fechado */}
                {order.status === 'fechado' && !order.rating && (
                  <div className="mt-4 p-3 bg-purple-50 border border-purple-200 rounded-xl flex items-center justify-between">
                    <div className="text-xs text-purple-900">
                      <span className="font-bold">Serviço em andamento com {acceptedQuote?.proName || 'o profissional'}!</span>
                      <p className="text-[11px] text-purple-700">Quando a execução for concluída, confirme para liberar a avaliação.</p>
                    </div>
                    <button
                      onClick={() => {
                        completeOrder(order.id);
                        onOpenReviewModal(order.id);
                      }}
                      className="bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold px-4 py-1.5 rounded-full shadow-xs transition-colors shrink-0"
                    >
                      Concluir e Avaliar
                    </button>
                  </div>
                )}

                {/* Review badge if rated */}
                {order.rating && (
                  <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900">
                    <div className="flex items-center gap-1 font-bold mb-1">
                      <div className="flex text-amber-500">
                        {Array.from({ length: order.rating.stars }).map((_, i) => (
                          <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                        ))}
                      </div>
                      <span>Sua avaliação ({order.rating.stars} estrelas)</span>
                    </div>
                    <p className="italic text-gray-700">"{order.rating.comment}"</p>
                  </div>
                )}
              </div>

              {/* Proposals Drawer */}
              <div className="bg-gray-50/60 border-t border-gray-100 p-5 sm:p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-blue-600" />
                    <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400">
                      Propostas Recebidas ({orderQuotes.length})
                    </h3>
                  </div>

                  <button
                    onClick={() => setExpandedOrderId(isExpanded ? null : order.id)}
                    className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1"
                  >
                    {isExpanded ? (
                      <>Ocultar <ChevronUp className="w-3.5 h-3.5" /></>
                    ) : (
                      <>Ver Propostas <ChevronDown className="w-3.5 h-3.5" /></>
                    )}
                  </button>
                </div>

                {orderQuotes.length === 0 ? (
                  <div className="text-center py-6 text-gray-500 text-xs">
                    <Clock className="w-5 h-5 mx-auto mb-1 text-gray-400 animate-spin" />
                    Aguardando orçamentos dos profissionais da região. Você será notificado assim que o primeiro Ninja responder!
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orderQuotes.map(quote => {
                      const isAccepted = quote.status === 'aceita' || order.acceptedQuoteId === quote.id;

                      return (
                        <div
                          key={quote.id}
                          className={`p-4 rounded-xl border transition-all ${
                            isAccepted
                              ? 'bg-emerald-50/60 border-emerald-300 ring-1 ring-emerald-500/20 shadow-xs'
                              : 'bg-white border-gray-200 hover:border-gray-300 shadow-xs'
                          }`}
                        >
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                            
                            {/* Pro Info */}
                            <div className="flex items-start gap-3">
                              <img
                                src={quote.proAvatar}
                                alt={quote.proName}
                                referrerPolicy="no-referrer"
                                className="w-12 h-12 rounded-full object-cover border border-gray-200 shrink-0"
                              />
                              <div>
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <h4 className="text-sm font-bold text-gray-900">
                                    {quote.proName}
                                  </h4>
                                  <span className="bg-blue-50 text-blue-700 border border-blue-100 text-[10px] font-semibold px-2 py-0.5 rounded-full flex items-center gap-0.5">
                                    <ShieldCheck className="w-3 h-3 text-blue-600" />
                                    Ninja Verificado
                                  </span>
                                </div>
                                <p className="text-xs text-gray-500 font-medium">
                                  {quote.proTitle}
                                </p>
                                
                                <div className="flex items-center gap-2 mt-1 text-xs">
                                  <div className="flex items-center text-amber-500 font-bold">
                                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                                    <span className="ml-1 text-gray-800">{quote.proRating}</span>
                                  </div>
                                  <span className="text-gray-300">•</span>
                                  <span className="text-gray-500">
                                    {quote.proReviewCount} avaliações
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Price & estimated time */}
                            <div className="text-left sm:text-right shrink-0 bg-gray-50 sm:bg-transparent p-2 sm:p-0 rounded-lg">
                              <span className="text-[10px] uppercase font-bold text-gray-400 block tracking-wider">
                                Valor da Proposta
                              </span>
                              <div className="text-xl font-extrabold text-gray-900">
                                R$ {quote.price.toLocaleString('pt-BR')}
                                <span className="text-xs font-normal text-gray-500 ml-1">
                                  {quote.priceUnit === 'por_hora' ? '/hora' : 'total'}
                                </span>
                              </div>
                              <span className="text-[11px] text-gray-500 flex items-center sm:justify-end gap-1 mt-0.5">
                                <Calendar className="w-3 h-3" />
                                {quote.estimatedDays}
                              </span>
                            </div>
                          </div>

                          {/* Message from Pro */}
                          <div className="mt-3 p-3 bg-gray-50 rounded-xl border border-gray-100 text-xs text-gray-700 leading-relaxed">
                            <span className="font-bold text-gray-900 block mb-0.5">Mensagem do Ninja:</span>
                            "{quote.message}"
                          </div>

                          {/* Action Buttons */}
                          <div className="mt-4 pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-2">
                            <button
                              onClick={() => openChatForOrder(order.id)}
                              className="px-3.5 py-1.5 rounded-full border border-gray-200 hover:border-gray-300 text-gray-700 hover:bg-gray-50 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                            >
                              <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
                              <span>Conversar no Chat</span>
                            </button>

                            {isAccepted ? (
                              <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-full">
                                <CheckCircle className="w-4 h-4" />
                                <span>Orçamento Escolhido</span>
                              </div>
                            ) : order.status === 'fechado' || order.status === 'concluido' ? (
                              <span className="text-xs text-gray-400 italic">
                                Outro orçamento foi escolhido
                              </span>
                            ) : (
                              <button
                                onClick={() => acceptQuote(quote.id)}
                                className="px-4 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Aceitar Orçamento</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};

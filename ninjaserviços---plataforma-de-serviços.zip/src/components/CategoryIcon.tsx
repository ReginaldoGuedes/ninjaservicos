import React from 'react';
import {
  Hammer,
  Wrench,
  Sparkles,
  GraduationCap,
  PartyPopper,
  Car,
  Scissors,
  Laptop,
  HelpCircle,
  LucideProps
} from 'lucide-react';

interface CategoryIconProps extends LucideProps {
  name: string;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({ name, ...props }) => {
  switch (name) {
    case 'Hammer':
      return <Hammer {...props} />;
    case 'Wrench':
      return <Wrench {...props} />;
    case 'Sparkles':
      return <Sparkles {...props} />;
    case 'GraduationCap':
      return <GraduationCap {...props} />;
    case 'PartyPopper':
      return <PartyPopper {...props} />;
    case 'Car':
      return <Car {...props} />;
    case 'Scissors':
      return <Scissors {...props} />;
    case 'Laptop':
      return <Laptop {...props} />;
    default:
      return <HelpCircle {...props} />;
  }
};

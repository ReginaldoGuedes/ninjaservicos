import React, { useState } from 'react';
import { useNinja } from '../context/NinjaContext';
import {
  X,
  Star,
  CheckCircle,
  ThumbsUp
} from 'lucide-react';

interface ReviewModalProps {
  orderId: string | null;
  onClose: () => void;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({ orderId, onClose }) => {
  const { orders, reviewOrder } = useNinja();
  const [stars, setStars] = useState<number>(5);
  const [comment, setComment] = useState<string>('Serviço excelente, profissional muito atencioso, pontual e cumpriu exatamente o acordado!');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!orderId) return null;
  const order = orders.find(o => o.id === orderId);
  if (!order) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    reviewOrder(orderId, stars, comment);
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-xl border border-gray-200">
        
        <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-white">
          <h3 className="text-sm font-bold text-gray-900">
            Avaliar Profissional Ninja
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center py-12 space-y-2">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle className="w-7 h-7" />
            </div>
            <h4 className="text-lg font-bold text-gray-900">
              Obrigado pela sua avaliação!
            </h4>
            <p className="text-xs text-gray-500">
              Sua avaliação ajuda outros clientes a escolherem os melhores profissionais.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="text-center space-y-1">
              <p className="text-xs font-medium text-gray-500">Como foi a sua experiência com o serviço?</p>
              <div className="font-bold text-gray-900 text-sm">{order.title}</div>
            </div>

            {/* Stars selection */}
            <div className="flex items-center justify-center gap-2 py-2">
              {[1, 2, 3, 4, 5].map(s => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setStars(s)}
                  className="p-1 text-gray-200 hover:text-yellow-400 transition-colors"
                >
                  <Star
                    className={`w-8 h-8 ${
                      s <= stars
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-200'
                    }`}
                  />
                </button>
              ))}
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Deixe um comentário:
              </label>
              <textarea
                rows={3}
                required
                value={comment}
                onChange={e => setComment(e.target.value)}
                className="w-full p-3 rounded-xl border border-gray-200 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white transition-colors"
                placeholder="Conte sobre pontualidade, qualidade e atendimento..."
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-full shadow-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <ThumbsUp className="w-4 h-4" />
              Publicar Avaliação
            </button>
          </form>
        )}

      </div>
    </div>
  );
};

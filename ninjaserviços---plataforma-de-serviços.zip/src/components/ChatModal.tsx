import React, { useState, useRef, useEffect } from 'react';
import { useNinja } from '../context/NinjaContext';
import {
  X,
  Send,
  Phone,
  CheckCircle,
  ShieldCheck,
  Calendar,
  DollarSign
} from 'lucide-react';

export const ChatModal: React.FC = () => {
  const {
    activeChatOrderId,
    closeChat,
    orders,
    quotes,
    chatMessages,
    sendChatMessage,
    userMode,
    currentPro,
    clientProfile,
    acceptQuote
  } = useNinja();

  const [inputMessage, setInputMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const order = orders.find(o => o.id === activeChatOrderId);
  const orderQuotes = quotes.filter(q => q.orderId === activeChatOrderId);
  const relevantMessages = chatMessages.filter(m => m.orderId === activeChatOrderId);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [relevantMessages]);

  if (!activeChatOrderId || !order) return null;

  const otherPersonName = userMode === 'client' 
    ? (orderQuotes[0]?.proName || 'Profissional Ninja') 
    : order.clientName;

  const otherPersonAvatar = userMode === 'client'
    ? (orderQuotes[0]?.proAvatar || 'https://images.unsplash.com/photo-1540569014015-19a7be504e3a?auto=format&fit=crop&q=80&w=250')
    : (order.clientAvatar || clientProfile.avatar);

  const activeQuote = orderQuotes.find(q => q.status === 'enviada' || q.status === 'aceita');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;
    sendChatMessage(order.id, inputMessage);
    setInputMessage('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl w-full max-w-lg h-[85vh] max-h-[680px] overflow-hidden shadow-xl border border-gray-200 flex flex-col">
        
        {/* Chat Header */}
        <div className="p-4 border-b border-gray-100 bg-white flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src={otherPersonAvatar}
              alt={otherPersonName}
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-full object-cover border border-gray-200 shrink-0"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-bold text-gray-900">{otherPersonName}</h3>
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
              </div>
              <p className="text-[11px] text-gray-500 line-clamp-1">
                {order.title}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {order.unlockedByPros.includes(currentPro.id) && (
              <a
                href={`tel:${order.clientPhone}`}
                title="Ligar para o cliente"
                className="p-2 text-gray-500 hover:text-blue-600 hover:bg-gray-100 rounded-full transition-colors"
              >
                <Phone className="w-4 h-4" />
              </a>
            )}
            <button
              onClick={closeChat}
              className="p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Quote notification ribbon if proposal exists */}
        {activeQuote && (
          <div className="px-4 py-2.5 bg-gray-50 border-b border-gray-100 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-gray-800">
              <DollarSign className="w-4 h-4 text-blue-600 shrink-0" />
              <span>
                Orçamento: <strong className="text-gray-900 font-bold">R$ {activeQuote.price}</strong> ({activeQuote.estimatedDays})
              </span>
            </div>

            {userMode === 'client' && activeQuote.status === 'enviada' && (
              <button
                onClick={() => acceptQuote(activeQuote.id)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[11px] px-3 py-1 rounded-full shadow-xs transition-colors"
              >
                Aceitar Orçamento
              </button>
            )}

            {activeQuote.status === 'aceita' && (
              <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full">
                Acordo Fechado
              </span>
            )}
          </div>
        )}

        {/* Chat Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50/50">
          <div className="text-center my-2">
            <span className="text-[10px] text-gray-500 bg-white border border-gray-200 px-3 py-1 rounded-full shadow-xs">
              Canal de negociação segura NinjaServiços
            </span>
          </div>

          {relevantMessages.map(msg => {
            const isMe = (userMode === 'client' && msg.senderRole === 'client') ||
                         (userMode === 'pro' && msg.senderRole === 'pro');

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <span className="text-[10px] text-gray-400 mb-0.5 px-1">
                  {msg.senderName}
                </span>
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-xs sm:text-sm shadow-xs ${
                    isMe
                      ? 'bg-blue-600 text-white rounded-tr-xs'
                      : 'bg-white text-gray-800 border border-gray-200 rounded-tl-xs'
                  }`}
                >
                  <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                </div>
                <span className="text-[9px] text-gray-400 mt-0.5 px-1">
                  {msg.timestamp}
                </span>
              </div>
            );
          })}

          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input */}
        <form onSubmit={handleSend} className="p-3 border-t border-gray-100 bg-white flex items-center gap-2">
          <input
            type="text"
            value={inputMessage}
            onChange={e => setInputMessage(e.target.value)}
            placeholder="Digite sua mensagem para negociar..."
            className="flex-1 px-4 py-2.5 rounded-full border border-gray-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 bg-gray-50 focus:bg-white transition-colors"
          />
          <button
            type="submit"
            disabled={!inputMessage.trim()}
            className="bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white p-2.5 rounded-full shadow-xs transition-colors shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};

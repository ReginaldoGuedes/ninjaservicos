import React from 'react';
import { useNinja } from '../context/NinjaContext';
import {
  Coins,
  PlusCircle,
  ClipboardList,
  Search,
  Briefcase,
  UserCheck,
  Zap,
  RotateCcw,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  openCreateOrderModal: () => void;
  openCoinModal: () => void;
  openProRegisterModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  openCreateOrderModal,
  openCoinModal,
  openProRegisterModal
}) => {
  const {
    userMode,
    setUserMode,
    currentPro,
    orders,
    quotes,
    resetDemoData
  } = useNinja();

  // Count active proposals for client
  const myClientOrders = orders.filter(o => o.clientName === 'Fernanda Albuquerque');
  const quotesCount = quotes.filter(q => myClientOrders.some(o => o.id === q.orderId)).length;

  // Unlocked orders by pro
  const unlockedCount = orders.filter(o => o.unlockedByPros.includes(currentPro.id)).length;

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-gray-200">
      {/* Top Banner Notice */}
      <div className="bg-gray-50 border-b border-gray-100 text-gray-500 text-xs py-1.5 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="bg-blue-50 text-blue-700 font-bold px-2 py-0.5 rounded-full text-[10px] tracking-wide border border-blue-100">
              NinjaPRO
            </span>
            <span className="hidden sm:inline text-gray-500 text-xs">
              Conectando quem precisa com os melhores profissionais de São Paulo e do Brasil.
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={resetDemoData}
              title="Restaurar dados de demonstração"
              className="text-gray-500 hover:text-blue-600 flex items-center gap-1 text-[11px] transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span className="hidden md:inline">Restaurar Dados Demo</span>
            </button>
            <div className="text-gray-500 text-[11px] flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-500" />
              <span>Profissionais Verificados</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18 gap-2 sm:gap-4">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => {
                if (userMode === 'client') {
                  setCurrentTab('explore');
                } else {
                  setCurrentTab('marketplace');
                }
              }}
              className="flex items-center gap-2.5 text-left group"
            >
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-xs transition-transform group-hover:scale-105 shrink-0">
                <span>N</span>
              </div>
              <div>
                <span className="text-xl font-bold tracking-tight text-blue-900 font-sans">
                  Ninja<span className="text-blue-600">PRO</span>
                </span>
              </div>
            </button>

            {/* Mode Switcher Pill */}
            <div className="hidden lg:flex items-center bg-gray-100 p-1 rounded-full border border-gray-200 ml-2">
              <button
                type="button"
                onClick={() => {
                  setUserMode('client');
                  setCurrentTab('explore');
                }}
                className={`px-4 py-1 rounded-full text-xs font-semibold transition-all ${
                  userMode === 'client'
                    ? 'bg-white text-blue-700 shadow-sm font-bold'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Sou Cliente
              </button>
              <button
                type="button"
                onClick={() => {
                  setUserMode('pro');
                  setCurrentTab('marketplace');
                }}
                className={`px-4 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  userMode === 'pro'
                    ? 'bg-blue-600 text-white shadow-sm font-bold'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Zap className="w-3.5 h-3.5 text-amber-300" />
                Sou Profissional Ninja
              </button>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="flex items-center gap-1 sm:gap-4">
            {userMode === 'client' ? (
              <>
                <button
                  onClick={() => setCurrentTab('explore')}
                  className={`hidden md:flex items-center gap-1.5 px-3 py-2 text-sm font-medium transition-colors ${
                    currentTab === 'explore'
                      ? 'text-blue-600 font-semibold'
                      : 'text-gray-600 hover:text-blue-600'
                  }`}
                >
                  <Search className="w-4 h-4" />
                  Buscar
                </button>

                <button
                  onClick={() => setCurrentTab('my_orders')}
                  className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium transition-colors relative ${
                    currentTab === 'my_orders'
                      ? 'text-blue-600 font-semibold'
                      : 'text-gray-600 hover:text-blue-600'
                  }`}
                >
                  <ClipboardList className="w-4 h-4" />
                  <span>Meus Pedidos</span>
                  {quotesCount > 0 && (
                    <span className="bg-blue-600 text-white text-[11px] font-bold px-1.5 py-0.2 rounded-full">
                      {quotesCount}
                    </span>
                  )}
                </button>

                <div className="h-4 w-px bg-gray-300 hidden md:block"></div>

                <button
                  type="button"
                  onClick={openProRegisterModal}
                  className="hidden xl:flex items-center gap-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-3 py-1.5 rounded-full transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Cadastrar Prestador (+25 Moedas)</span>
                </button>

                <button
                  onClick={openCreateOrderModal}
                  className="bg-blue-600 text-white px-5 py-2 rounded-full hover:bg-blue-700 text-xs sm:text-sm font-medium transition-colors shadow-xs flex items-center gap-1.5"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>Anunciar Pedido</span>
                </button>
              </>
            ) : (
              <>
                {/* Ninja Coins Balance & Recharge */}
                <div className="flex items-center gap-1.5 bg-yellow-50 border border-yellow-200 px-3 py-1.5 rounded-full text-xs">
                  <Coins className="w-3.5 h-3.5 text-yellow-700 fill-yellow-600" />
                  <span className="font-bold text-yellow-900">
                    {currentPro.coins}
                  </span>
                  <span className="text-yellow-700 hidden sm:inline font-medium">
                    Moedas
                  </span>
                  <button
                    onClick={openCoinModal}
                    title="Recarregar Moedas Ninja"
                    className="ml-1 bg-yellow-500 hover:bg-yellow-600 text-white w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold transition-colors"
                  >
                    +
                  </button>
                </div>

                <button
                  onClick={() => setCurrentTab('marketplace')}
                  className={`flex items-center gap-1.5 px-3 py-2 text-xs sm:text-sm font-medium transition-colors ${
                    currentTab === 'marketplace'
                      ? 'text-blue-600 font-semibold'
                      : 'text-gray-600 hover:text-blue-600'
                  }`}
                >
                  <Briefcase className="w-4 h-4" />
                  <span className="hidden sm:inline">Mural de Pedidos</span>
                  <span className="sm:hidden">Pedidos</span>
                </button>

                <button
                  onClick={() => setCurrentTab('pro_jobs')}
                  className={`flex items-center gap-1.5 px-3 py-2 text-xs sm:text-sm font-medium transition-colors relative ${
                    currentTab === 'pro_jobs'
                      ? 'text-blue-600 font-semibold'
                      : 'text-gray-600 hover:text-blue-600'
                  }`}
                >
                  <ClipboardList className="w-4 h-4" />
                  <span className="hidden md:inline">Meus Atendimentos</span>
                  <span className="md:hidden">Atendimentos</span>
                  {unlockedCount > 0 && (
                    <span className="bg-emerald-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                      {unlockedCount}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setCurrentTab('pro_profile')}
                  className={`flex items-center gap-1.5 px-3 py-2 text-xs sm:text-sm font-medium transition-colors ${
                    currentTab === 'pro_profile'
                      ? 'text-blue-600 font-semibold'
                      : 'text-gray-600 hover:text-blue-600'
                  }`}
                >
                  <UserCheck className="w-4 h-4" />
                  <span className="hidden lg:inline">Meu Perfil</span>
                </button>
              </>
            )}

            {/* Small Mobile Mode Switcher */}
            <div className="lg:hidden flex items-center ml-1">
              <button
                onClick={() => {
                  const nextMode = userMode === 'client' ? 'pro' : 'client';
                  setUserMode(nextMode);
                  setCurrentTab(nextMode === 'client' ? 'explore' : 'marketplace');
                }}
                className="bg-gray-100 hover:bg-gray-200 text-gray-800 text-[11px] font-medium px-2.5 py-1.5 rounded-full border border-gray-200 flex items-center gap-1"
              >
                {userMode === 'client' ? (
                  <>
                    <Zap className="w-3 h-3 text-amber-500" />
                    <span>Ninja</span>
                  </>
                ) : (
                  <span>Cliente</span>
                )}
              </button>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
};

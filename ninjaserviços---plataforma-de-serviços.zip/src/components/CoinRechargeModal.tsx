import React, { useState, useEffect } from 'react';
import { useNinja } from '../context/NinjaContext';
import { COIN_PACKAGES } from '../data/categories';
import {
  X,
  Coins,
  CheckCircle,
  Copy,
  Check,
  QrCode,
  ShieldCheck,
  ArrowLeft,
  Clock,
  Sparkles,
  Zap,
  Building2,
  RefreshCw
} from 'lucide-react';

interface CoinRechargeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CoinRechargeModal: React.FC<CoinRechargeModalProps> = ({
  isOpen,
  onClose
}) => {
  const { currentPro, rechargeCoins, resetToWelcomeCoins } = useNinja();
  const [selectedPackId, setSelectedPackId] = useState<string>('pack-2');
  const [step, setStep] = useState<'select' | 'pix' | 'success'>('select');
  const [copied, setCopied] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [purchasedAmount, setPurchasedAmount] = useState<number>(0);
  const [countdown, setCountdown] = useState(15 * 60); // 15 minutes in seconds

  const selectedPack = COIN_PACKAGES.find(p => p.id === selectedPackId) || COIN_PACKAGES[1];

  // Pix Code generation tailored to chosen package
  const pixCode = `00020126580014br.gov.bcb.pix0136pix-cobranca@ninjaservicos.com.br520400005303986540${selectedPack.price.toFixed(2)}5802BR5924Ninja Servicos Intermed6009SAO PAULO62140510NINJA${selectedPack.coins}M6304${(Math.random() * 9000 + 1000).toFixed(0)}`;

  // Countdown timer for Pix expiration
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (step === 'pix' && countdown > 0) {
      timer = setInterval(() => {
        setCountdown(prev => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [step, countdown]);

  if (!isOpen) return null;

  const handleClose = () => {
    setStep('select');
    setCopied(false);
    setIsVerifying(false);
    onClose();
  };

  const handleGoToPix = () => {
    setCountdown(15 * 60);
    setCopied(false);
    setStep('pix');
  };

  const handleCopyPix = () => {
    navigator.clipboard.writeText(pixCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleSimulatePayment = () => {
    setIsVerifying(true);
    setTimeout(() => {
      const added = rechargeCoins(selectedPack.id) || selectedPack.coins;
      setPurchasedAmount(added);
      setIsVerifying(false);
      setStep('success');
    }, 1200);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl border border-gray-200 max-h-[92vh] flex flex-col">
        
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-gray-100 flex items-center justify-between bg-white shrink-0">
          <div className="flex items-center gap-3">
            {step === 'pix' && (
              <button
                type="button"
                onClick={() => setStep('select')}
                className="p-1.5 -ml-1 text-gray-400 hover:text-gray-800 rounded-full hover:bg-gray-100 transition-colors"
                title="Voltar aos pacotes"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center">
              <Coins className="w-5 h-5 fill-amber-500 text-amber-800" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-gray-900">
                {step === 'pix' ? 'Pagamento via Pix' : 'Recarregar Moedas Ninja'}
              </h2>
              <p className="text-xs text-gray-500">
                Saldo atual: <strong className="font-bold text-gray-900">{currentPro.coins} moedas</strong>
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-700 p-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          
          {/* STEP 1: SELECT PACKAGE */}
          {step === 'select' && (
            <>
              {/* Welcome Bonus Notice */}
              <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl text-xs text-blue-900 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-blue-950">
                  <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>Regra de Moedas & Boas-Vindas</span>
                </div>
                <p className="text-blue-800 text-[11px] leading-relaxed">
                  Todo novo prestador ganha <strong>25 moedas gratuitas no cadastro</strong> para fechar sua <strong>1ª negociação de teste</strong>. Após utilizá-las, o desbloqueio de novos clientes é feito comprando moedas via Pix.
                </p>
              </div>

              {/* Packages List */}
              <div className="space-y-2.5">
                <div className="text-xs font-semibold text-gray-600">
                  Selecione o pacote desejado para recarregar:
                </div>

                {COIN_PACKAGES.map(pack => {
                  const isSelected = selectedPackId === pack.id;
                  const estimatedLeads = Math.floor(pack.coins / 18);

                  return (
                    <div
                      key={pack.id}
                      onClick={() => setSelectedPackId(pack.id)}
                      className={`p-3.5 sm:p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50/30 shadow-xs ring-1 ring-blue-500/20'
                          : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50/70'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="radio"
                          name="coin_pack"
                          checked={isSelected}
                          onChange={() => setSelectedPackId(pack.id)}
                          className="text-blue-600 focus:ring-blue-500 w-4 h-4"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm sm:text-base font-bold text-gray-900">
                              {pack.coins} Moedas
                            </span>
                            {pack.popular && (
                              <span className="bg-amber-100 border border-amber-300 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                                Mais Escolhido
                              </span>
                            )}
                            {pack.coins === 600 && (
                              <span className="bg-emerald-100 border border-emerald-300 text-emerald-900 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                                Maior Economia
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-gray-500 block mt-0.5">
                            Libera aprox. {estimatedLeads} a {estimatedLeads + 1} contatos de clientes
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-base sm:text-lg font-black text-gray-900">
                          R$ {pack.price.toFixed(2).replace('.', ',')}
                        </span>
                        <span className="text-[10px] text-gray-400 block font-medium">via Pix</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Guarantees */}
              <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center gap-2 text-[11px] text-gray-600">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Liberação imediata via Pix QR Code ou Copia e Cola. As moedas nunca expiram.</span>
              </div>

              {/* Bottom Actions */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={resetToWelcomeCoins}
                  title="Reiniciar saldo para as 25 moedas de boas-vindas"
                  className="text-[11px] text-gray-500 hover:text-blue-600 flex items-center gap-1 font-medium transition-colors"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Testar 25 moedas de boas-vindas</span>
                </button>

                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <button
                    type="button"
                    onClick={handleClose}
                    className="px-4 py-2 text-xs font-semibold text-gray-500 hover:text-gray-800 rounded-full"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={handleGoToPix}
                    className="flex-1 sm:flex-none px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm rounded-full shadow-xs flex items-center justify-center gap-2 transition-colors"
                  >
                    <QrCode className="w-4 h-4" />
                    <span>Pagar R$ {selectedPack.price.toFixed(2).replace('.', ',')} via Pix</span>
                  </button>
                </div>
              </div>
            </>
          )}

          {/* STEP 2: PIX QR CODE & COPIA E COLA */}
          {step === 'pix' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              
              {/* Value and Expiration Pill */}
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-3.5 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block tracking-wider">
                    Total a Pagar
                  </span>
                  <div className="text-xl font-black text-gray-900">
                    R$ {selectedPack.price.toFixed(2).replace('.', ',')}
                  </div>
                  <span className="text-xs text-blue-700 font-semibold">
                    +{selectedPack.coins} Moedas NinjaPRO
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-gray-400 block tracking-wider">
                    Tempo Restante
                  </span>
                  <div className="flex items-center gap-1 text-sm font-bold text-amber-700">
                    <Clock className="w-4 h-4" />
                    <span>{formatTime(countdown)}</span>
                  </div>
                </div>
              </div>

              {/* QR Code Container */}
              <div className="flex flex-col items-center justify-center p-4 bg-white border border-gray-200 rounded-2xl shadow-xs">
                <div className="relative p-3 bg-white rounded-xl border border-gray-200 shadow-xs flex items-center justify-center">
                  
                  {/* Clean, authentic vector SVG QR Code */}
                  <svg
                    className="w-48 h-48 sm:w-52 sm:h-52"
                    viewBox="0 0 200 200"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    {/* Background */}
                    <rect width="200" height="200" fill="white" />
                    
                    {/* Top-Left Finder Pattern */}
                    <rect x="15" y="15" width="45" height="45" rx="6" fill="#111827" />
                    <rect x="22" y="22" width="31" height="31" rx="4" fill="white" />
                    <rect x="28" y="28" width="19" height="19" rx="2" fill="#111827" />
                    
                    {/* Top-Right Finder Pattern */}
                    <rect x="140" y="15" width="45" height="45" rx="6" fill="#111827" />
                    <rect x="147" y="22" width="31" height="31" rx="4" fill="white" />
                    <rect x="153" y="28" width="19" height="19" rx="2" fill="#111827" />

                    {/* Bottom-Left Finder Pattern */}
                    <rect x="15" y="140" width="45" height="45" rx="6" fill="#111827" />
                    <rect x="22" y="147" width="31" height="31" rx="4" fill="white" />
                    <rect x="28" y="153" width="19" height="19" rx="2" fill="#111827" />

                    {/* QR Matrix Elements (Simulated Standard Pix Pattern) */}
                    <g fill="#1F2937">
                      {/* Top horizontal timing */}
                      <rect x="68" y="22" width="6" height="6" rx="1" />
                      <rect x="80" y="22" width="6" height="6" rx="1" />
                      <rect x="92" y="22" width="6" height="6" rx="1" />
                      <rect x="104" y="22" width="6" height="6" rx="1" />
                      <rect x="116" y="22" width="6" height="6" rx="1" />
                      <rect x="128" y="22" width="6" height="6" rx="1" />

                      {/* Left vertical timing */}
                      <rect x="22" y="68" width="6" height="6" rx="1" />
                      <rect x="22" y="80" width="6" height="6" rx="1" />
                      <rect x="22" y="92" width="6" height="6" rx="1" />
                      <rect x="22" y="104" width="6" height="6" rx="1" />
                      <rect x="22" y="116" width="6" height="6" rx="1" />
                      <rect x="22" y="128" width="6" height="6" rx="1" />

                      {/* Data clusters */}
                      <rect x="68" y="38" width="14" height="6" rx="1" />
                      <rect x="90" y="38" width="6" height="14" rx="1" />
                      <rect x="108" y="38" width="18" height="6" rx="1" />

                      <rect x="38" y="68" width="16" height="6" rx="1" />
                      <rect x="68" y="68" width="8" height="8" rx="1" />
                      <rect x="84" y="68" width="14" height="6" rx="1" />
                      <rect x="108" y="68" width="8" height="8" rx="1" />
                      <rect x="126" y="68" width="14" height="6" rx="1" />
                      <rect x="150" y="68" width="8" height="8" rx="1" />
                      <rect x="166" y="68" width="18" height="6" rx="1" />

                      <rect x="38" y="84" width="8" height="14" rx="1" />
                      <rect x="54" y="84" width="14" height="6" rx="1" />
                      <rect x="140" y="84" width="14" height="14" rx="1" />
                      <rect x="164" y="84" width="8" height="8" rx="1" />
                      <rect x="180" y="84" width="6" height="14" rx="1" />

                      <rect x="68" y="102" width="8" height="8" rx="1" />
                      <rect x="122" y="102" width="12" height="8" rx="1" />
                      <rect x="160" y="102" width="8" height="8" rx="1" />

                      <rect x="38" y="118" width="14" height="8" rx="1" />
                      <rect x="68" y="118" width="12" height="6" rx="1" />
                      <rect x="90" y="118" width="8" height="8" rx="1" />
                      <rect x="110" y="118" width="16" height="8" rx="1" />
                      <rect x="140" y="118" width="8" height="8" rx="1" />
                      <rect x="160" y="118" width="18" height="8" rx="1" />

                      <rect x="68" y="140" width="14" height="8" rx="1" />
                      <rect x="90" y="140" width="8" height="8" rx="1" />
                      <rect x="110" y="140" width="14" height="8" rx="1" />
                      <rect x="135" y="140" width="8" height="8" rx="1" />
                      <rect x="155" y="140" width="16" height="8" rx="1" />
                      <rect x="178" y="140" width="8" height="8" rx="1" />

                      <rect x="68" y="160" width="8" height="16" rx="1" />
                      <rect x="84" y="160" width="14" height="8" rx="1" />
                      <rect x="108" y="160" width="8" height="8" rx="1" />
                      <rect x="126" y="160" width="18" height="8" rx="1" />
                      <rect x="154" y="160" width="8" height="8" rx="1" />
                      <rect x="170" y="160" width="14" height="8" rx="1" />

                      <rect x="84" y="174" width="8" height="8" rx="1" />
                      <rect x="102" y="174" width="14" height="8" rx="1" />
                      <rect x="126" y="174" width="8" height="8" rx="1" />
                      <rect x="145" y="174" width="18" height="8" rx="1" />
                    </g>

                    {/* Central Pix Logo Badge */}
                    <rect x="82" y="82" width="36" height="36" rx="8" fill="white" stroke="#E5E7EB" strokeWidth="2" />
                    <path
                      d="M93.5 100L100 93.5L106.5 100L100 106.5L93.5 100Z"
                      fill="#32BCAD"
                    />
                    <circle cx="100" cy="100" r="2.5" fill="white" />
                  </svg>
                </div>
                
                <span className="text-[11px] text-gray-500 font-medium mt-2 flex items-center gap-1.5">
                  <QrCode className="w-3.5 h-3.5 text-gray-400" />
                  Aponte a câmera do aplicativo do seu banco para o QR Code
                </span>
              </div>

              {/* PIX COPIA E COLA */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider">
                  Pix Copia e Cola
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={pixCode}
                    className="w-full px-3 py-2 text-xs font-mono bg-gray-50 border border-gray-300 rounded-xl text-gray-700 select-all truncate focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleCopyPix}
                    className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 shrink-0 transition-all ${
                      copied
                        ? 'bg-emerald-600 text-white'
                        : 'bg-gray-900 hover:bg-black text-white'
                    }`}
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4" />
                        <span>Copiado!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span>Copiar Código</span>
                      </>
                    )}
                  </button>
                </div>
                {copied && (
                  <p className="text-[11px] text-emerald-600 font-semibold animate-in fade-in">
                    Código Pix copiado! Abra o aplicativo do seu banco e escolha "Pix Copia e Cola".
                  </p>
                )}
              </div>

              {/* Receiver Info */}
              <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 text-xs text-gray-600 space-y-1">
                <div className="flex items-center justify-between text-gray-800 font-semibold">
                  <span className="flex items-center gap-1">
                    <Building2 className="w-3.5 h-3.5 text-gray-500" />
                    NinjaServiços Intermediação S.A.
                  </span>
                  <span className="text-[11px] text-gray-500 font-normal">CNPJ: 42.190.874/0001-35</span>
                </div>
                <div className="text-[11px] text-gray-500">
                  Banco Liquidante: Banco Central do Brasil (SPI / Pix Instantâneo)
                </div>
              </div>

              {/* Instructions */}
              <div className="space-y-1 text-[11px] text-gray-500 list-decimal list-inside bg-blue-50/50 p-3 rounded-xl border border-blue-100">
                <div className="font-bold text-blue-900 mb-1">Como pagar:</div>
                <p>1. Abra o app do seu banco e acesse a seção <strong>Pix</strong>.</p>
                <p>2. Selecione <strong>Pagar com QR Code</strong> ou <strong>Pix Copia e Cola</strong>.</p>
                <p>3. Conclua a transferência no valor exato de <strong>R$ {selectedPack.price.toFixed(2).replace('.', ',')}</strong>.</p>
                <p>4. As moedas caem imediatamente na sua conta NinjaPRO!</p>
              </div>

              {/* Bottom Action: Simular Webhook / Verificar Pagamento */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setStep('select')}
                  className="text-xs font-semibold text-gray-500 hover:text-gray-900"
                >
                  Voltar e alterar pacote
                </button>

                <button
                  type="button"
                  disabled={isVerifying}
                  onClick={handleSimulatePayment}
                  className="w-full sm:w-auto px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-400 text-white font-semibold text-xs sm:text-sm rounded-full shadow-xs flex items-center justify-center gap-2 transition-colors"
                >
                  {isVerifying ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Identificando no Banco Central...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      <span>Já Fiz o Pix (Confirmar Pagamento)</span>
                    </>
                  )}
                </button>
              </div>

            </div>
          )}

          {/* STEP 3: SUCCESS CONFIRMATION */}
          {step === 'success' && (
            <div className="text-center py-10 space-y-4 animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto animate-bounce">
                <CheckCircle className="w-9 h-9" />
              </div>
              
              <div className="space-y-1">
                <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
                  Pix Confirmado com Sucesso!
                </span>
                <h3 className="text-2xl font-black text-gray-900">
                  +{purchasedAmount} Moedas Creditadas
                </h3>
                <p className="text-xs text-gray-500 max-w-sm mx-auto">
                  Seu novo saldo é de <strong className="text-gray-900 font-bold">{currentPro.coins} moedas</strong>. Agora você já pode liberar contatos no mural e enviar suas propostas!
                </p>
              </div>

              <div className="pt-4">
                <button
                  type="button"
                  onClick={handleClose}
                  className="px-8 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm rounded-full shadow-xs transition-colors"
                >
                  Ir para o Mural de Pedidos
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { useNinja } from '../context/NinjaContext';
import { SERVICE_CATEGORIES } from '../data/categories';
import { CategoryIcon } from './CategoryIcon';
import { CURRENT_NINJA_PRO, OTHER_PROS } from '../data/initialData';
import {
  Search,
  CheckCircle2,
  ShieldCheck,
  Star,
  Clock,
  ArrowRight,
  TrendingUp,
  MapPin,
  Sparkles,
  Zap
} from 'lucide-react';

interface ClientHomeProps {
  onOpenCreateOrder: (categoryId?: string) => void;
  onNavigateToOrders: () => void;
}

export const ClientHome: React.FC<ClientHomeProps> = ({
  onOpenCreateOrder,
  onNavigateToOrders
}) => {
  const { orders, setUserMode } = useNinja();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');

  const filteredCategories = SERVICE_CATEGORIES.filter(cat => {
    if (selectedCategoryFilter !== 'all' && cat.id !== selectedCategoryFilter) {
      return false;
    }
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      cat.name.toLowerCase().includes(q) ||
      cat.description.toLowerCase().includes(q) ||
      cat.subcategories.some(sub => sub.toLowerCase().includes(q)) ||
      cat.popularTags.some(tag => tag.toLowerCase().includes(q))
    );
  });

  const popularSearches = [
    { label: 'Eletricista', categoryId: 'reformas' },
    { label: 'Diarista', categoryId: 'servicos_domesticos' },
    { label: 'Ar-Condicionado', categoryId: 'assistencia' },
    { label: 'Pintor', categoryId: 'reformas' },
    { label: 'Conserto de Celular', categoryId: 'assistencia' },
    { label: 'Mecânico', categoryId: 'autos' },
    { label: 'Aulas de Inglês', categoryId: 'aulas' }
  ];

  return (
    <div className="space-y-12 pb-16">
      
      {/* HERO SECTION */}
      <header className="bg-white px-4 sm:px-8 py-12 sm:py-16 text-center border-b border-gray-100">
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-blue-700 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Mais de 15.000 profissionais em São Paulo e em todo o Brasil</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-gray-900 tracking-tight leading-tight">
            O que você precisa hoje?
          </h1>

          <p className="text-base sm:text-lg text-gray-500 max-w-2xl mx-auto leading-relaxed">
            Encontre os melhores profissionais de São Paulo avaliados por clientes reais. Receba até 4 orçamentos gratuitos.
          </p>

          {/* Search Box */}
          <div className="max-w-2xl mx-auto relative pt-2">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-4 top-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Ex: Reformas, Aulas de Inglês, Diarista, Eletricista..."
                className="w-full pl-12 pr-36 py-3.5 sm:py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white text-sm sm:text-base text-gray-900 transition-all shadow-xs"
              />
              <button
                onClick={() => {
                  const matched = SERVICE_CATEGORIES.find(c => 
                    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    c.subcategories.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()))
                  );
                  onOpenCreateOrder(matched?.id);
                }}
                className="absolute right-2 top-2 bottom-2 bg-blue-600 hover:bg-blue-700 text-white px-5 sm:px-6 rounded-xl font-semibold text-xs sm:text-sm shadow-sm transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Buscar</span>
                <ArrowRight className="w-4 h-4 hidden sm:inline" />
              </button>
            </div>
          </div>

          {/* Quick pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-2 text-xs text-gray-500">
            <span className="font-semibold text-gray-400 mr-1 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-gray-400" /> Mais buscados:
            </span>
            {popularSearches.map(item => (
              <button
                key={item.label}
                onClick={() => {
                  setSearchQuery(item.label);
                  onOpenCreateOrder(item.categoryId);
                }}
                className="bg-gray-100 hover:bg-gray-200 text-gray-700 border border-gray-200 px-3 py-1 rounded-full transition-colors font-medium text-xs"
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Trust badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 border-t border-gray-100 text-left sm:text-center max-w-2xl mx-auto">
            <div className="flex items-center justify-center gap-1.5 text-xs text-gray-500">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>100% Grátis p/ clientes</span>
            </div>
            <div className="flex items-center justify-center gap-1.5 text-xs text-gray-500">
              <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
              <span>Ninjas Verificados</span>
            </div>
            <div className="flex items-center justify-center gap-1.5 text-xs text-gray-500">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500 shrink-0" />
              <span>Avaliações Reais</span>
            </div>
            <div className="flex items-center justify-center gap-1.5 text-xs text-gray-500">
              <Clock className="w-4 h-4 text-gray-400 shrink-0" />
              <span>Resposta Rápida</span>
            </div>
          </div>
        </div>
      </header>

      {/* FEATURED PROFESSIONALS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400">
              Profissionais em Destaque
            </h3>
            <h2 className="text-xl sm:text-2xl font-extrabold text-gray-900 mt-0.5">
              Profissionais mais bem avaliados em São Paulo
            </h2>
          </div>
          <button
            onClick={() => onOpenCreateOrder()}
            className="text-blue-600 text-xs font-bold hover:underline hidden sm:inline"
          >
            Ver todos na região
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[CURRENT_NINJA_PRO, ...OTHER_PROS.slice(0, 2)].map(pro => (
            <div
              key={pro.id}
              className="bg-white p-5 rounded-2xl border border-gray-100 shadow-xs flex flex-col hover:border-gray-200 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-14 h-14 bg-gray-100 rounded-full overflow-hidden border-2 border-white shadow-inner flex items-center justify-center shrink-0">
                  {pro.avatar ? (
                    <img
                      src={pro.avatar}
                      alt={pro.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-lg">
                      {pro.name.slice(0, 2).toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="bg-yellow-50 text-yellow-700 px-2 py-1 rounded-md text-xs font-bold flex items-center gap-1 border border-yellow-200/50">
                  <span>⭐</span>
                  <span>{pro.rating.toFixed(1)}</span>
                </div>
              </div>

              <h4 className="font-bold text-gray-900 text-base">{pro.name}</h4>
              <p className="text-xs text-gray-500 mb-4 line-clamp-1">{pro.title}</p>

              <div className="mt-auto pt-4 border-t border-gray-50 flex items-center justify-between">
                <span className="text-xs text-gray-400">
                  {pro.reviewCount} avaliações • {pro.completedJobsCount} serviços
                </span>
                <button
                  onClick={() => onOpenCreateOrder(pro.category)}
                  className="text-blue-600 hover:text-blue-700 font-bold text-sm hover:underline"
                >
                  Orçar
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CATEGORIES SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 gap-4">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-1">
              Categorias Populares
            </h3>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900">
              O que você precisa resolver hoje?
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              Selecione a categoria desejada para receber orçamentos detalhados.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
            <button
              onClick={() => setSelectedCategoryFilter('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategoryFilter === 'all'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Todas ({SERVICE_CATEGORIES.length})
            </button>
            {SERVICE_CATEGORIES.slice(0, 4).map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategoryFilter(cat.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedCategoryFilter === cat.id
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredCategories.map(cat => (
            <div
              key={cat.id}
              className="bg-white rounded-xl border border-gray-100 hover:border-blue-200 hover:shadow-sm p-4 sm:p-5 transition-all group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${cat.color} transition-colors group-hover:scale-105`}>
                    <CategoryIcon name={cat.icon} className="w-5 h-5" />
                  </div>
                  <span className="text-[11px] font-medium text-gray-400 bg-gray-50 border border-gray-100 px-2 py-0.5 rounded-md">
                    {cat.subcategories.length} serviços
                  </span>
                </div>

                <h3 className="text-base font-bold text-gray-900 group-hover:text-blue-600 transition-colors mb-1">
                  {cat.name}
                </h3>
                <p className="text-xs text-gray-500 line-clamp-2 mb-3 leading-relaxed">
                  {cat.description}
                </p>

                {/* Popular Tags */}
                <div className="flex flex-wrap gap-1.5 mb-3">
                  {cat.popularTags.slice(0, 3).map(tag => (
                    <span
                      key={tag}
                      className="text-[10px] font-medium bg-gray-50 text-gray-600 border border-gray-100 px-2 py-0.5 rounded-md"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-gray-50 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-gray-400 block font-medium">Média Brasil</span>
                  <span className="text-xs font-bold text-gray-700">{cat.averagePriceRange}</span>
                </div>
                <button
                  onClick={() => onOpenCreateOrder(cat.id)}
                  className="text-blue-600 font-bold text-sm hover:underline flex items-center gap-1"
                >
                  <span>Orçar</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS SECTION (GETNINJAS 3-STEP PROCESS) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl border border-gray-200 p-8 sm:p-12 text-gray-900 shadow-xs">
          <div className="max-w-3xl mb-8">
            <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-1">
              Simples, Rápido e Seguro
            </h3>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900">
              Como funciona o NinjaPRO
            </h2>
            <p className="text-gray-500 text-sm mt-1">
              O modelo inteligente estilo GetNinjas que protege seu tempo e garante as melhores opções de contratação.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Step 1 */}
            <div className="bg-gray-50 border border-gray-100 rounded-xl p-6">
              <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-bold text-sm flex items-center justify-center mb-4">
                1
              </div>
              <h3 className="text-base font-bold text-gray-900 mb-2">
                Faça o seu pedido grátis
              </h3>
              <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                Conte em poucos cliques qual serviço precisa, detalhes do problema, urgência e sua localização. Leva menos de 2 minutos.
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-gray-50 border border-gray-100 rounded-xl p-6">
              <div className="w-8 h-8 rounded-lg bg-yellow-500 text-gray-950 font-bold text-sm flex items-center justify-center mb-4">
                2
              </div>
              <h3 className="text-base font-bold text-gray-900 mb-2">
                Receba até 4 orçamentos
              </h3>
              <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                Profissionais qualificados da sua região desbloqueiam seu contato e enviam propostas com valores, prazos e garantia.
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-gray-50 border border-gray-100 rounded-xl p-6">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white font-bold text-sm flex items-center justify-center mb-4">
                3
              </div>
              <h3 className="text-base font-bold text-gray-900 mb-2">
                Escolha o melhor Ninja
              </h3>
              <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                Compare perfis, notas e avaliações de outros clientes, converse diretamente pelo chat e feche negócio com total tranquilidade.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* RECENT ACTIVE ORDERS (COMMUNITY PULSE) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400">
              Mural em Tempo Real
            </h3>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
                Pedidos em Andamento na Rede
              </h2>
            </div>
          </div>

          <button
            onClick={onNavigateToOrders}
            className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 hover:underline"
          >
            <span>Ver Meus Pedidos</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {orders.slice(0, 3).map(order => (
            <div
              key={order.id}
              className="bg-white p-5 rounded-xl border border-gray-100 shadow-xs flex flex-col justify-between hover:border-gray-200 transition-all"
            >
              <div>
                <div className="flex items-center justify-between text-[11px] mb-2">
                  <span className="font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100">
                    {order.subcategory}
                  </span>
                  <span className="text-gray-400">{order.createdAt}</span>
                </div>
                <h4 className="font-bold text-gray-900 text-sm mb-1 line-clamp-2">
                  {order.title}
                </h4>
                <p className="text-xs text-gray-500 line-clamp-2 mb-3">
                  {order.description}
                </p>
              </div>

              <div className="pt-3 border-t border-gray-50 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1 text-gray-500">
                  <MapPin className="w-3.5 h-3.5 text-gray-400" />
                  <span>{order.location.neighborhood}, {order.location.city}</span>
                </div>
                <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">
                  {order.unlockedByPros.length}/{order.maxUnlocks} propostas
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CALL TO ACTION FOR PROFESSIONALS / FREELANCERS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white border border-gray-200 rounded-2xl p-6 sm:p-10 shadow-xs flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <span className="bg-blue-50 text-blue-700 border border-blue-100 text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              Para Profissionais e Autônomos
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-gray-900">
              Quer aumentar sua renda e conquistar mais clientes?
            </h3>
            <p className="text-xs sm:text-sm text-gray-600 max-w-xl">
              Cadastre-se como prestador e ganhe <strong>25 moedas gratuitas de boas-vindas</strong> para fechar sua 1ª negociação! Após utilizar o bônus, recarregue pacotes via Pix a partir de R$ 20,00 e receba contatos diretos sem intermediários.
            </p>
          </div>

          <button
            onClick={() => setUserMode('pro')}
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm px-6 py-3 rounded-full shadow-xs transition-colors flex items-center gap-2 shrink-0"
          >
            <Zap className="w-4 h-4 text-yellow-300 fill-yellow-300" />
            <span>Mudar para Modo Ninja (+25 Moedas)</span>
          </button>
        </div>
      </section>

    </div>
  );
};

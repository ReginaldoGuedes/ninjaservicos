import React, { useState } from 'react';
import { useNinja } from '../context/NinjaContext';
import { SERVICE_CATEGORIES } from '../data/categories';
import { CategoryIcon } from './CategoryIcon';
import { UrgencyLevel } from '../types';
import {
  X,
  ArrowRight,
  ArrowLeft,
  CheckCircle,
  MapPin,
  Clock,
  Sparkles,
  ShieldCheck,
  Zap
} from 'lucide-react';

interface CreateOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedCategoryId?: string;
  onOrderCreated?: (orderId: string) => void;
}

export const CreateOrderModal: React.FC<CreateOrderModalProps> = ({
  isOpen,
  onClose,
  preselectedCategoryId,
  onOrderCreated
}) => {
  const { createOrder } = useNinja();

  const [step, setStep] = useState<number>(1);
  const [selectedCategory, setSelectedCategory] = useState<string>(preselectedCategoryId || 'reformas');
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>('');
  
  // Step 2 form
  const [title, setTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [urgency, setUrgency] = useState<UrgencyLevel>('esta_semana');

  // Step 3 form
  const [city, setCity] = useState<string>('São Paulo');
  const [state, setState] = useState<string>('SP');
  const [neighborhood, setNeighborhood] = useState<string>('Pinheiros');
  const [cep, setCep] = useState<string>('05422-000');
  const [customBudget, setCustomBudget] = useState<string>('');

  const [isSuccess, setIsSuccess] = useState<boolean>(false);

  if (!isOpen) return null;

  const currentCategoryData = SERVICE_CATEGORIES.find(c => c.id === selectedCategory) || SERVICE_CATEGORIES[0];

  const handleNext = () => {
    if (step === 1 && !selectedSubcategory) {
      // Auto-pick first subcategory if not selected
      setSelectedSubcategory(currentCategoryData.subcategories[0]);
    }
    setStep(prev => prev + 1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const orderTitle = title.trim() || `${selectedSubcategory || currentCategoryData.name} - ${neighborhood}`;
    const orderDesc = description.trim() || `Preciso de um profissional experiente para realização de serviço de ${selectedSubcategory}. Favor enviar orçamento detalhado e disponibilidade.`;
    
    // Determine fair coin cost for professional unlock (15 to 25 coins)
    const coinCost = urgency === 'urgente' ? 22 : 18;

    const newOrder = createOrder({
      title: orderTitle,
      category: selectedCategory,
      subcategory: selectedSubcategory || currentCategoryData.subcategories[0],
      description: orderDesc,
      urgency,
      location: {
        city,
        state,
        neighborhood,
        cep
      },
      estimatedBudget: customBudget.trim() || currentCategoryData.averagePriceRange,
      coinCost
    });

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setStep(1);
      setTitle('');
      setDescription('');
      onClose();
      if (onOrderCreated) {
        onOrderCreated(newOrder.id);
      }
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl w-full max-w-2xl overflow-hidden shadow-xl border border-gray-200 flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
              {step}/3
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-gray-900">
                Pedir Orçamento Grátis
              </h2>
              <p className="text-xs text-gray-500">
                {step === 1 && 'Escolha a categoria e especialidade'}
                {step === 2 && 'Descreva o que você precisa'}
                {step === 3 && 'Sua localização e envio'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Splash */}
        {isSuccess ? (
          <div className="p-8 text-center flex flex-col items-center justify-center my-auto py-16">
            <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 animate-bounce">
              <CheckCircle className="w-9 h-9" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">
              Pedido Publicado com Sucesso!
            </h3>
            <p className="text-sm text-gray-600 max-w-md mb-4">
              Seu pedido já está visível para os melhores profissionais avaliados da sua região. Você receberá até 4 orçamentos para comparar.
            </p>
            <div className="flex items-center gap-2 text-xs font-semibold text-blue-700 bg-blue-50 px-3.5 py-1.5 rounded-full border border-blue-100">
              <Zap className="w-3.5 h-3.5" />
              Notificando profissionais qualificados...
            </div>
          </div>
        ) : (
          <div className="overflow-y-auto p-6 flex-1">
            {/* STEP 1: Select Category & Subcategory */}
            {step === 1 && (
              <div className="space-y-5">
                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-2.5">
                    1. Qual categoria de serviço?
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {SERVICE_CATEGORIES.map(cat => {
                      const isSelected = selectedCategory === cat.id;
                      return (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => {
                            setSelectedCategory(cat.id);
                            setSelectedSubcategory(cat.subcategories[0]);
                          }}
                          className={`p-3 rounded-xl text-left border transition-all flex flex-col items-start justify-between min-h-[90px] ${
                            isSelected
                              ? 'border-gray-900 bg-gray-50 ring-1 ring-gray-900 shadow-xs'
                              : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50/60'
                          }`}
                        >
                          <div className={`p-2 rounded-lg ${cat.color} mb-2`}>
                            <CategoryIcon name={cat.icon} className="w-4 h-4" />
                          </div>
                          <span className="text-xs font-bold text-gray-900 line-clamp-1">
                            {cat.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Subcategories */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-2">
                    2. Escolha a especialidade exata:
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {currentCategoryData.subcategories.map(sub => {
                      const isSelected = selectedSubcategory === sub || (!selectedSubcategory && sub === currentCategoryData.subcategories[0]);
                      return (
                        <button
                          key={sub}
                          type="button"
                          onClick={() => setSelectedSubcategory(sub)}
                          className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all ${
                            isSelected
                              ? 'bg-blue-600 text-white shadow-xs font-semibold'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200/60'
                          }`}
                        >
                          {sub}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Price hint */}
                <div className="bg-gray-50 border border-gray-200 p-3.5 rounded-xl flex items-center justify-between text-xs text-gray-800">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-blue-600" />
                    <span>Faixa média estimada para esta categoria:</span>
                  </div>
                  <span className="font-bold text-gray-900">
                    {currentCategoryData.averagePriceRange}
                  </span>
                </div>
              </div>
            )}

            {/* STEP 2: Details & Urgency */}
            {step === 2 && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                    Título do seu pedido
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    placeholder={`Ex: Instalação de ${selectedSubcategory || 'ventilador'}`}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 bg-gray-50 focus:bg-white transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                    Descreva os detalhes do que precisa ser feito
                  </label>
                  <textarea
                    rows={4}
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    placeholder="Descreva a quantidade, tamanho, se você já possui os materiais ou precisa que o profissional compre, e preferências de dia/horário..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 bg-gray-50 focus:bg-white transition-colors"
                  />
                  <p className="text-[11px] text-gray-500 mt-1">
                    Quanto mais detalhes você fornecer, mais precisos serão os orçamentos recebidos.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-2">
                    Quando você precisa deste serviço?
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {[
                      { id: 'urgente', label: 'Urgente / O quanto antes', desc: 'Preciso para hoje ou amanhã' },
                      { id: 'esta_semana', label: 'Esta semana', desc: 'Nos próximos 3 a 5 dias' },
                      { id: 'proximos_15_dias', label: 'Próximas semanas', desc: 'Prazo mais flexível' },
                      { id: 'apenas_orcamento', label: 'Apenas pesquisando', desc: 'Planejando orçamento futuro' },
                    ].map(opt => {
                      const isSelected = urgency === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setUrgency(opt.id as UrgencyLevel)}
                          className={`p-3 rounded-xl text-left border transition-all ${
                            isSelected
                              ? 'border-gray-900 bg-gray-50 ring-1 ring-gray-900'
                              : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-gray-900">{opt.label}</span>
                            <Clock className={`w-3.5 h-3.5 ${isSelected ? 'text-blue-600' : 'text-gray-400'}`} />
                          </div>
                          <p className="text-[11px] text-gray-500 mt-0.5">{opt.desc}</p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* STEP 3: Location & Confirmation */}
            {step === 3 && (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Cidade
                    </label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={e => setCity(e.target.value)}
                      placeholder="Ex: São Paulo"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 bg-gray-50 focus:bg-white transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Estado (UF)
                    </label>
                    <select
                      value={state}
                      onChange={e => setState(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 bg-gray-50 focus:bg-white transition-colors"
                    >
                      <option value="SP">SP - São Paulo</option>
                      <option value="RJ">RJ - Rio de Janeiro</option>
                      <option value="MG">MG - Minas Gerais</option>
                      <option value="PR">PR - Paraná</option>
                      <option value="RS">RS - Rio Grande do Sul</option>
                      <option value="SC">SC - Santa Catarina</option>
                      <option value="BA">BA - Bahia</option>
                      <option value="DF">DF - Distrito Federal</option>
                      <option value="GO">GO - Goiás</option>
                      <option value="PE">PE - Pernambuco</option>
                      <option value="CE">CE - Ceará</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Bairro
                    </label>
                    <input
                      type="text"
                      required
                      value={neighborhood}
                      onChange={e => setNeighborhood(e.target.value)}
                      placeholder="Ex: Pinheiros / Moema"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 bg-gray-50 focus:bg-white transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      CEP (Opcional)
                    </label>
                    <input
                      type="text"
                      value={cep}
                      onChange={e => setCep(e.target.value)}
                      placeholder="00000-000"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 bg-gray-50 focus:bg-white transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                    Pretensão de orçamento (Opcional)
                  </label>
                  <input
                    type="text"
                    value={customBudget}
                    onChange={e => setCustomBudget(e.target.value)}
                    placeholder={`Ex: Até R$ 400 ou ${currentCategoryData.averagePriceRange}`}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 bg-gray-50 focus:bg-white transition-colors"
                  />
                  <span className="text-[11px] text-gray-500">
                    Os profissionais enviarão valores exatos com base no seu pedido.
                  </span>
                </div>

                {/* Summary Box */}
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-3.5 text-xs text-gray-700 space-y-1.5">
                  <div className="font-bold text-gray-900 flex items-center justify-between">
                    <span>Resumo do Pedido:</span>
                    <span className="text-blue-600 font-semibold">{currentCategoryData.name}</span>
                  </div>
                  <p><span className="text-gray-500">Serviço:</span> {selectedSubcategory || currentCategoryData.name}</p>
                  <p><span className="text-gray-500">Local:</span> {neighborhood}, {city} - {state}</p>
                  <div className="pt-2 border-t border-gray-200 flex items-center gap-1.5 text-emerald-700 font-medium">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Grátis para o cliente. Até 4 profissionais certificados receberão seu pedido.</span>
                  </div>
                </div>
              </form>
            )}
          </div>
        )}

        {/* Footer controls */}
        {!isSuccess && (
          <div className="px-6 py-4 border-t border-gray-100 flex items-center justify-between bg-white">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep(prev => prev - 1)}
                className="px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-900 flex items-center gap-1 hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Voltar
              </button>
            ) : (
              <div />
            )}

            {step < 3 ? (
              <button
                type="button"
                onClick={handleNext}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold rounded-full flex items-center gap-1.5 shadow-xs transition-colors"
              >
                Continuar
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold rounded-full flex items-center gap-1.5 shadow-xs transition-colors"
              >
                <CheckCircle className="w-4 h-4" />
                Publicar Pedido Grátis
              </button>
            )}
          </div>
        )}

      </div>
    </div>
  );
};

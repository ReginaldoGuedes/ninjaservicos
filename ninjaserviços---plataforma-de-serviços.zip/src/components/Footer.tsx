import React from 'react';
import { ShieldCheck, Heart, MapPin } from 'lucide-react';
import { SERVICE_CATEGORIES } from '../data/categories';

interface FooterProps {
  onSelectCategory: (catId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectCategory }) => {
  return (
    <footer className="bg-white text-gray-500 text-xs border-t border-gray-200 pt-10 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Col */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-xs shrink-0">
                <span>N</span>
              </div>
              <span className="text-xl font-bold tracking-tight text-blue-900 font-sans">
                Ninja<span className="text-blue-600">PRO</span>
              </span>
            </div>
            <p className="text-gray-500 text-xs leading-relaxed">
              Encontre os melhores profissionais de São Paulo e de todo o Brasil avaliados por clientes reais com orçamentos rápidos e gratuitos.
            </p>
            <div className="flex items-center gap-1.5 text-[11px] text-gray-500">
              <ShieldCheck className="w-4 h-4 text-blue-600" />
              <span>Ambiente 100% seguro com garantia NinjaPRO</span>
            </div>
          </div>

          {/* Categorias Principais */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-400">
              Categorias Populares
            </h4>
            <ul className="space-y-1.5 text-gray-600">
              {SERVICE_CATEGORIES.slice(0, 5).map(cat => (
                <li key={cat.id}>
                  <button
                    onClick={() => onSelectCategory(cat.id)}
                    className="hover:text-blue-600 transition-colors text-left"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Serviços Mais Buscados */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-400">
              Mais Buscados
            </h4>
            <ul className="space-y-1.5 text-gray-600">
              <li className="hover:text-blue-600 cursor-pointer transition-colors">Eletricista Residencial</li>
              <li className="hover:text-blue-600 cursor-pointer transition-colors">Conserto de Ar-Condicionado</li>
              <li className="hover:text-blue-600 cursor-pointer transition-colors">Diarista e Faxina Pós-Obra</li>
              <li className="hover:text-blue-600 cursor-pointer transition-colors">Conserto de Celular & Notebook</li>
              <li className="hover:text-blue-600 cursor-pointer transition-colors">Pintor e Texturas</li>
              <li className="hover:text-blue-600 cursor-pointer transition-colors">Personal Trainer & Aulas</li>
            </ul>
          </div>

          {/* Cidades Atendidas */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-widest text-gray-400">
              Principais Cidades
            </h4>
            <div className="flex flex-wrap gap-1.5 text-[11px]">
              {['São Paulo', 'Rio de Janeiro', 'Belo Horizonte', 'Curitiba', 'Porto Alegre', 'Salvador', 'Brasília', 'Campinas'].map(city => (
                <span
                  key={city}
                  className="bg-gray-50 border border-gray-200 text-gray-600 px-2 py-0.5 rounded-md flex items-center gap-1"
                >
                  <MapPin className="w-2.5 h-2.5 text-gray-400" />
                  {city}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-gray-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-400">
          <div>
            © {new Date().getFullYear()} NinjaPRO Marketplace. Todos os direitos reservados.
          </div>
          <div className="flex items-center gap-6">
            <a href="#privacidade" onClick={(e) => e.preventDefault()} className="hover:text-blue-600 transition-colors">Privacidade</a>
            <a href="#termos" onClick={(e) => e.preventDefault()} className="hover:text-blue-600 transition-colors">Termos de Uso</a>
            <a href="#ajuda" onClick={(e) => e.preventDefault()} className="hover:text-blue-600 transition-colors">Ajuda</a>
          </div>
        </div>

      </div>
    </footer>
  );
};

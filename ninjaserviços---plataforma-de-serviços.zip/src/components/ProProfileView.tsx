import React, { useState } from 'react';
import { useNinja } from '../context/NinjaContext';
import {
  ShieldCheck,
  Star,
  Award,
  Clock,
  Briefcase,
  MapPin,
  Phone,
  CheckCircle2,
  Calendar,
  Zap,
  Edit3,
  Check,
  Coins
} from 'lucide-react';

interface ProProfileViewProps {
  onOpenCoinModal: () => void;
}

export const ProProfileView: React.FC<ProProfileViewProps> = ({ onOpenCoinModal }) => {
  const { currentPro, orders } = useNinja();

  const [isEditing, setIsEditing] = useState(false);
  const [bio, setBio] = useState(currentPro.bio);
  const [title, setTitle] = useState(currentPro.title);
  const [phone, setPhone] = useState(currentPro.phone);

  const ratedOrders = orders.filter(o => o.unlockedByPros.includes(currentPro.id) && o.rating);

  const handleSave = () => {
    currentPro.bio = bio;
    currentPro.title = title;
    currentPro.phone = phone;
    setIsEditing(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Profile Header Card */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 sm:p-8 shadow-xs relative">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pb-6 border-b border-gray-100">
          
          <div className="flex items-center gap-5">
            <img
              src={currentPro.avatar}
              alt={currentPro.name}
              referrerPolicy="no-referrer"
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-full object-cover border border-gray-200 shadow-xs shrink-0"
            />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl font-extrabold text-gray-900">
                  {currentPro.name}
                </h1>
                <span className="bg-blue-50 text-blue-700 border border-blue-100 text-xs font-semibold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                  Ninja Verificado
                </span>
              </div>

              {isEditing ? (
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="mt-1.5 px-3 py-1.5 text-xs border border-gray-200 rounded-xl w-full font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              ) : (
                <p className="text-xs sm:text-sm text-gray-500 font-medium mt-1">
                  {currentPro.title}
                </p>
              )}

              <div className="flex items-center gap-3 text-xs text-gray-500 mt-2">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-gray-400" />
                  {currentPro.city}, {currentPro.state}
                </span>
                <span className="text-gray-300">•</span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-gray-400" />
                  No app desde {currentPro.memberSince}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center">
            {isEditing ? (
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-full flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <Check className="w-3.5 h-3.5" />
                Salvar Perfil
              </button>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="px-4 py-2 border border-gray-200 hover:border-gray-300 text-gray-700 text-xs font-semibold rounded-full flex items-center gap-1.5 hover:bg-gray-50 transition-colors"
              >
                <Edit3 className="w-3.5 h-3.5" />
                Editar Dados
              </button>
            )}
          </div>
        </div>

        {/* Stats strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-6 border-b border-gray-100 text-center">
          <div>
            <span className="text-2xl font-extrabold text-yellow-500 flex items-center justify-center gap-1">
              <Star className="w-5 h-5 fill-yellow-400" />
              {currentPro.rating}
            </span>
            <span className="text-xs text-gray-500 block mt-0.5">
              {currentPro.reviewCount} avaliações
            </span>
          </div>

          <div>
            <span className="text-2xl font-extrabold text-gray-900">
              {currentPro.completedJobsCount}
            </span>
            <span className="text-xs text-gray-500 block mt-0.5">
              Serviços Concluídos
            </span>
          </div>

          <div>
            <span className="text-2xl font-extrabold text-emerald-600">
              {currentPro.responseTime}
            </span>
            <span className="text-xs text-gray-500 block mt-0.5">
              Tempo de Resposta
            </span>
          </div>

          <div>
            <div className="flex items-center justify-center gap-1.5">
              <span className="text-2xl font-extrabold text-yellow-600">
                {currentPro.coins}
              </span>
              <button
                onClick={onOpenCoinModal}
                className="bg-yellow-500 hover:bg-yellow-600 text-gray-950 text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs transition-colors"
              >
                +
              </button>
            </div>
            <span className="text-xs text-gray-500 block mt-0.5">
              Moedas Ninja
            </span>
          </div>
        </div>

        {/* Bio */}
        <div className="py-6 border-b border-gray-100 space-y-2">
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">
            Sobre o Profissional
          </h3>
          {isEditing ? (
            <textarea
              rows={4}
              value={bio}
              onChange={e => setBio(e.target.value)}
              className="w-full p-3 border border-gray-200 rounded-xl text-xs sm:text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          ) : (
            <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
              {currentPro.bio}
            </p>
          )}
        </div>

        {/* Specialties */}
        <div className="py-6 border-b border-gray-100 space-y-2.5">
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">
            Especialidades Atendidas
          </h3>
          <div className="flex flex-wrap gap-2">
            {currentPro.specialties.map(spec => (
              <span
                key={spec}
                className="bg-gray-100 text-gray-800 text-xs font-medium px-3 py-1 rounded-full border border-gray-200"
              >
                {spec}
              </span>
            ))}
          </div>
        </div>

        {/* Ninja Quality Badges */}
        <div className="py-6 space-y-3">
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">
            Selos de Confiança Ninja
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-gray-50 border border-gray-200 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <div className="font-bold text-gray-900">Documentos Verificados</div>
                <div className="text-gray-500 text-[11px]">Identidade e CPF validados</div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-gray-50 border border-gray-200 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-yellow-50 text-yellow-600 flex items-center justify-center shrink-0">
                <Award className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <div className="font-bold text-gray-900">Super Ninja</div>
                <div className="text-gray-500 text-[11px]">Top 5% avaliados de SP</div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-gray-50 border border-gray-200 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <div className="font-bold text-gray-900">Pontualidade 99%</div>
                <div className="text-gray-500 text-[11px]">Chegada no horário marcado</div>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Customer Reviews Section */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 sm:p-8 shadow-xs space-y-4">
        <h2 className="text-lg font-bold text-gray-900">
          Avaliações Recentes de Clientes
        </h2>

        <div className="space-y-3">
          <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100 space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs text-gray-900">Fernanda Albuquerque</span>
                <span className="text-[11px] text-gray-400">Vila Mariana, SP</span>
              </div>
              <div className="flex text-yellow-500">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-yellow-400" />
                ))}
              </div>
            </div>
            <p className="text-xs text-gray-600 italic leading-relaxed">
              "Carlos foi extremamente pontual e profissional. Instalou os dois ventiladores de teto perfeitamente, sem sujeira, e ainda resolveu o problema do disjuntor do chuveiro. Super recomendo!"
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100 space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs text-gray-900">Roberto Antunes</span>
                <span className="text-[11px] text-gray-400">Pinheiros, SP</span>
              </div>
              <div className="flex text-yellow-500">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-yellow-400" />
                ))}
              </div>
            </div>
            <p className="text-xs text-gray-600 italic leading-relaxed">
              "Ótimo atendimento, trocou todo o quadro de disjuntores da minha casa em meio período com nota fiscal e garantia. Preço super justo pelo GetNinjas."
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};

import React, { useState } from 'react';
import { useNinja } from '../context/NinjaContext';
import { ServiceOrder } from '../types';
import {
  X,
  Send,
  Sparkles,
  ShieldCheck,
  CheckCircle,
  Calendar,
  AlertCircle
} from 'lucide-react';

interface ProQuoteModalProps {
  order: ServiceOrder | null;
  onClose: () => void;
  onQuoteSuccess?: () => void;
}

export const ProQuoteModal: React.FC<ProQuoteModalProps> = ({
  order,
  onClose,
  onQuoteSuccess
}) => {
  const { submitQuote } = useNinja();

  const [price, setPrice] = useState<number>(300);
  const [priceUnit, setPriceUnit] = useState<'total' | 'por_hora' | 'a_combinar'>('total');
  const [estimatedDays, setEstimatedDays] = useState<string>('Execução em 1 dia útil');
  const [message, setMessage] = useState<string>(
    'Olá! Tenho total disponibilidade para realizar o serviço com qualidade e rapidez. Levo ferramentas próprias e ofereço garantia de 6 meses.'
  );
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isSuccess, setIsSuccess] = useState<boolean>(false);

  if (!order) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!price || price <= 0) {
      setErrorMsg('Informe um valor válido para o orçamento.');
      return;
    }

    const res = submitQuote({
      orderId: order.id,
      price,
      priceUnit,
      estimatedDays,
      message
    });

    if (res.success) {
      setIsSuccess(true);
      setTimeout(() => {
        setIsSuccess(false);
        onClose();
        if (onQuoteSuccess) onQuoteSuccess();
      }, 1500);
    } else {
      setErrorMsg(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-xl border border-gray-200">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-white">
          <div>
            <span className="text-[11px] font-bold text-blue-600 uppercase tracking-wider">
              Proposta Ninja
            </span>
            <h2 className="text-base sm:text-lg font-bold text-gray-900">
              Enviar Orçamento
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center py-12 space-y-3">
            <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-gray-900">
              Orçamento Enviado com Sucesso!
            </h3>
            <p className="text-xs text-gray-500">
              O cliente foi notificado e a conversa foi iniciada no chat para você fechar os detalhes.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            
            {/* Target Order Summary */}
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-3 text-xs text-gray-700">
              <div className="font-bold text-gray-900 line-clamp-1">{order.title}</div>
              <div className="text-gray-500 mt-0.5">
                Cliente: <strong className="text-gray-800">{order.clientName}</strong> • {order.location.neighborhood}, {order.location.city}
              </div>
            </div>

            {errorMsg && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Price input & Unit */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                  Valor Proposto (R$)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-sm font-bold text-gray-400">R$</span>
                  <input
                    type="number"
                    min={10}
                    step={5}
                    required
                    value={price}
                    onChange={e => setPrice(Number(e.target.value))}
                    className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-gray-200 text-sm font-bold text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                  Tipo de Cobrança
                </label>
                <select
                  value={priceUnit}
                  onChange={e => setPriceUnit(e.target.value as any)}
                  className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white transition-colors"
                >
                  <option value="total">Preço Total Fechado</option>
                  <option value="por_hora">Por Hora Trabalhada</option>
                  <option value="a_combinar">A Combinar com o Cliente</option>
                </select>
              </div>
            </div>

            {/* Deadline */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                Prazo Estimado de Execução
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  value={estimatedDays}
                  onChange={e => setEstimatedDays(e.target.value)}
                  placeholder="Ex: Execução em 1 dia / Início imediato"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white transition-colors"
                />
              </div>
            </div>

            {/* Pitch Message */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                Mensagem para o Cliente
              </label>
              <textarea
                rows={4}
                required
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Apresente sua experiência, garantia, materiais inclusos e disponibilidade..."
                className="w-full p-3 rounded-xl border border-gray-200 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white transition-colors"
              />
            </div>

            <div className="bg-gray-50 p-3.5 rounded-xl border border-gray-100 flex items-center gap-2 text-[11px] text-gray-600">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>O cliente receberá sua proposta diretamente no painel e no chat. Sem comissão sobre o fechamento!</span>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-gray-500 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-full shadow-xs flex items-center gap-1.5 transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                Enviar Proposta Oficial
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};

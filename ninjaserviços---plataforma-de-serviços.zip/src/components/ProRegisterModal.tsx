import React, { useState } from 'react';
import { useNinja } from '../context/NinjaContext';
import { SERVICE_CATEGORIES } from '../data/categories';
import {
  X,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Coins,
  ArrowRight,
  User,
  Phone,
  MapPin,
  Briefcase
} from 'lucide-react';

interface ProRegisterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const ProRegisterModal: React.FC<ProRegisterModalProps> = ({
  isOpen,
  onClose,
  onSuccess
}) => {
  const { registerPro } = useNinja();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('São Paulo');
  const [state, setState] = useState('SP');
  const [category, setCategory] = useState(SERVICE_CATEGORIES[0].id);
  const [specialty, setSpecialty] = useState(SERVICE_CATEGORIES[0].subcategories[0]);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const currentCategoryObj = SERVICE_CATEGORIES.find(c => c.id === category) || SERVICE_CATEGORIES[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    registerPro({
      name: name.trim(),
      title: `${specialty} Profissional Certificado`,
      category,
      city: city.trim(),
      state,
      phone: phone.trim() || '(11) 98000-1234',
      specialties: [specialty, 'Atendimento Rápido', 'Orçamento Sem Compromisso']
    });

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
      onSuccess();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl border border-gray-200">
        
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-gray-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-gray-900">
                Cadastro de Prestador Ninja
              </h2>
              <p className="text-xs text-blue-700 font-semibold flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                Ganhe 25 Moedas Grátis no Cadastro!
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 p-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {isSuccess ? (
          <div className="p-8 text-center py-14 space-y-3">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle2 className="w-9 h-9" />
            </div>
            <span className="bg-amber-100 border border-amber-200 text-amber-900 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider inline-flex items-center gap-1">
              <Coins className="w-3.5 h-3.5 fill-amber-500 text-amber-800" />
              +25 Moedas Grátis Creditadas
            </span>
            <h3 className="text-2xl font-black text-gray-900">
              Conta Criada com Sucesso!
            </h3>
            <p className="text-xs text-gray-500 max-w-sm mx-auto">
              Seu bônus de 25 moedas está pronto para você liberar seu 1º cliente no mural e fechar sua negociação de teste!
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
            
            {/* Welcome Bonus Callout */}
            <div className="p-3.5 bg-amber-50/80 border border-amber-200 rounded-xl flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-200 text-amber-900 flex items-center justify-center shrink-0 mt-0.5">
                <Coins className="w-5 h-5 fill-amber-500 text-amber-800" />
              </div>
              <div className="text-xs text-amber-950">
                <strong className="block font-bold">Bônus de Boas-Vindas: 25 Moedas Gratuitas</strong>
                <p className="text-amber-900 text-[11px] mt-0.5 leading-relaxed">
                  Cadastre-se hoje e receba 25 moedas para desbloquear e fechar 1 negociação completa sem custo. Após utilizar o bônus, adquira pacotes via Pix a partir de R$ 20,00!
                </p>
              </div>
            </div>

            {/* Name */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                Seu Nome Completo
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Ex: Marcos Vinicius Silva"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white transition-colors"
                />
              </div>
            </div>

            {/* Category & Specialty */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                  Área de Atuação
                </label>
                <select
                  value={category}
                  onChange={e => {
                    setCategory(e.target.value);
                    const cat = SERVICE_CATEGORIES.find(c => c.id === e.target.value);
                    if (cat && cat.subcategories.length > 0) {
                      setSpecialty(cat.subcategories[0]);
                    }
                  }}
                  className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-xs font-medium text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white"
                >
                  {SERVICE_CATEGORIES.map(cat => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                  Especialidade Principal
                </label>
                <select
                  value={specialty}
                  onChange={e => setSpecialty(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-xs font-medium text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white"
                >
                  {currentCategoryObj.subcategories.map(sub => (
                    <option key={sub} value={sub}>
                      {sub}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* City, State & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                  Cidade e Estado
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={e => setCity(e.target.value)}
                    placeholder="Cidade"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                  WhatsApp com DDD
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="(11) 99999-8888"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-gray-200 text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 focus:bg-white transition-colors"
                  />
                </div>
              </div>
            </div>

            {/* Trust badge */}
            <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center gap-2 text-[11px] text-gray-600">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Sem taxa de adesão ou mensalidades. Comece com 25 moedas grátis!</span>
            </div>

            {/* Actions */}
            <div className="pt-2 flex items-center justify-end gap-3 border-t border-gray-100">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-gray-500 hover:text-gray-800 rounded-full"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm rounded-full shadow-xs flex items-center gap-2 transition-colors"
              >
                <span>Cadastrar e Ganhar 25 Moedas</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};

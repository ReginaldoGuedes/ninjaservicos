import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserMode,
  ServiceOrder,
  Quote,
  ProfessionalProfile,
  ChatMessage,
} from '../types';
import {
  CURRENT_NINJA_PRO,
  INITIAL_ORDERS,
  INITIAL_QUOTES,
  INITIAL_CHAT_MESSAGES
} from '../data/initialData';
import { COIN_PACKAGES } from '../data/categories';

interface ClientProfile {
  id: string;
  name: string;
  phone: string;
  city: string;
  state: string;
  avatar: string;
}

interface NinjaContextType {
  userMode: UserMode;
  setUserMode: (mode: UserMode) => void;
  orders: ServiceOrder[];
  quotes: Quote[];
  currentPro: ProfessionalProfile;
  clientProfile: ClientProfile;
  chatMessages: ChatMessage[];
  createOrder: (data: Omit<ServiceOrder, 'id' | 'createdAt' | 'status' | 'unlockedByPros' | 'maxUnlocks' | 'coinCost'> & { coinCost?: number }) => ServiceOrder;
  unlockLead: (orderId: string) => { success: boolean; message: string };
  submitQuote: (params: { orderId: string; price: number; estimatedDays: string; message: string; priceUnit: 'total' | 'por_hora' | 'a_combinar' }) => { success: boolean; message: string };
  acceptQuote: (quoteId: string) => void;
  completeOrder: (orderId: string) => void;
  reviewOrder: (orderId: string, stars: number, comment: string) => void;
  sendChatMessage: (orderId: string, text: string) => void;
  rechargeCoins: (packId: string) => number | undefined;
  registerPro: (data: { name: string; title: string; category: string; city: string; state: string; phone: string; specialties: string[] }) => ProfessionalProfile;
  resetToWelcomeCoins: () => void;
  openChatForOrder: (orderId: string) => void;
  closeChat: () => void;
  activeChatOrderId: string | null;
  activeOrderForQuote: ServiceOrder | null;
  setActiveOrderForQuote: (order: ServiceOrder | null) => void;
  resetDemoData: () => void;
}

const NinjaContext = createContext<NinjaContextType | undefined>(undefined);

const LOCAL_STORAGE_PREFIX = 'ninja_servicos_';

export const NinjaProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [userMode, setUserMode] = useState<UserMode>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_PREFIX + 'userMode');
    return (saved as UserMode) || 'client';
  });

  const [orders, setOrders] = useState<ServiceOrder[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_PREFIX + 'orders');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_ORDERS;
  });

  const [quotes, setQuotes] = useState<Quote[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_PREFIX + 'quotes');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_QUOTES;
  });

  const [currentPro, setCurrentPro] = useState<ProfessionalProfile>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_PREFIX + 'currentPro');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return CURRENT_NINJA_PRO;
  });

  const [clientProfile] = useState<ClientProfile>({
    id: 'client-me',
    name: 'Fernanda Albuquerque',
    phone: '(11) 98123-9988',
    city: 'São Paulo',
    state: 'SP',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200'
  });

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_PREFIX + 'chatMessages');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_CHAT_MESSAGES;
  });

  const [activeChatOrderId, setActiveChatOrderId] = useState<string | null>(null);
  const [activeOrderForQuote, setActiveOrderForQuote] = useState<ServiceOrder | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_PREFIX + 'userMode', userMode);
  }, [userMode]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_PREFIX + 'orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_PREFIX + 'quotes', JSON.stringify(quotes));
  }, [quotes]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_PREFIX + 'currentPro', JSON.stringify(currentPro));
  }, [currentPro]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_PREFIX + 'chatMessages', JSON.stringify(chatMessages));
  }, [chatMessages]);

  const createOrder = (data: Omit<ServiceOrder, 'id' | 'createdAt' | 'status' | 'unlockedByPros' | 'maxUnlocks' | 'coinCost'> & { coinCost?: number }) => {
    const newOrder: ServiceOrder = {
      ...data,
      id: 'order-' + Date.now(),
      createdAt: 'Agora mesmo',
      status: 'aberto',
      unlockedByPros: [],
      maxUnlocks: 4,
      coinCost: data.coinCost || 18,
      clientName: clientProfile.name,
      clientPhone: clientProfile.phone,
      clientAvatar: clientProfile.avatar
    };

    setOrders(prev => [newOrder, ...prev]);
    return newOrder;
  };

  const unlockLead = (orderId: string): { success: boolean; message: string } => {
    const order = orders.find(o => o.id === orderId);
    if (!order) {
      return { success: false, message: 'Pedido não encontrado.' };
    }

    if (order.unlockedByPros.includes(currentPro.id)) {
      return { success: true, message: 'Você já liberou este contato.' };
    }

    if (order.unlockedByPros.length >= order.maxUnlocks) {
      return { success: false, message: 'Limite de 4 profissionais atingido para este pedido.' };
    }

    if (currentPro.coins < order.coinCost) {
      return { success: false, message: `Saldo insuficiente! Você tem ${currentPro.coins} moedas e são necessárias ${order.coinCost} moedas.` };
    }

    // Deduct coins
    setCurrentPro(prev => ({
      ...prev,
      coins: prev.coins - order.coinCost
    }));

    // Add pro to unlocked list
    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          unlockedByPros: [...o.unlockedByPros, currentPro.id],
          status: o.status === 'aberto' ? 'em_negociacao' : o.status
        };
      }
      return o;
    }));

    return { success: true, message: `Contato liberado com sucesso! Gastou ${order.coinCost} moedas.` };
  };

  const submitQuote = (params: { orderId: string; price: number; estimatedDays: string; message: string; priceUnit: 'total' | 'por_hora' | 'a_combinar' }): { success: boolean; message: string } => {
    const newQuote: Quote = {
      id: 'quote-' + Date.now(),
      orderId: params.orderId,
      proId: currentPro.id,
      proName: currentPro.name,
      proAvatar: currentPro.avatar,
      proTitle: currentPro.title,
      proRating: currentPro.rating,
      proReviewCount: currentPro.reviewCount,
      price: params.price,
      priceUnit: params.priceUnit,
      estimatedDays: params.estimatedDays,
      message: params.message,
      createdAt: 'Agora mesmo',
      status: 'enviada'
    };

    setQuotes(prev => [newQuote, ...prev]);

    // Send an initial greeting message automatically in chat
    const introMsg: ChatMessage = {
      id: 'msg-' + Date.now(),
      orderId: params.orderId,
      senderId: currentPro.id,
      senderName: currentPro.name,
      senderRole: 'pro',
      text: `Olá! Enviei um orçamento no valor de R$ ${params.price} (${params.estimatedDays}). Qualquer dúvida sobre o serviço ou materiais, estou à disposição aqui no chat!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, introMsg]);

    setOrders(prev => prev.map(o => {
      if (o.id === params.orderId) {
        return { ...o, status: 'em_negociacao' };
      }
      return o;
    }));

    return { success: true, message: 'Orçamento enviado com sucesso ao cliente!' };
  };

  const acceptQuote = (quoteId: string) => {
    const targetQuote = quotes.find(q => q.id === quoteId);
    if (!targetQuote) return;

    setQuotes(prev => prev.map(q => {
      if (q.id === quoteId) return { ...q, status: 'aceita' };
      if (q.orderId === targetQuote.orderId) return { ...q, status: 'recusada' };
      return q;
    }));

    setOrders(prev => prev.map(o => {
      if (o.id === targetQuote.orderId) {
        return { ...o, status: 'fechado', acceptedQuoteId: quoteId };
      }
      return o;
    }));

    // Send confirmation in chat
    const msg: ChatMessage = {
      id: 'msg-' + Date.now(),
      orderId: targetQuote.orderId,
      senderId: clientProfile.id,
      senderName: clientProfile.name,
      senderRole: 'client',
      text: `🎉 Orçamento de R$ ${targetQuote.price} aceito! Vamos combinar os detalhes finais da execução.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setChatMessages(prev => [...prev, msg]);
  };

  const completeOrder = (orderId: string) => {
    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        return { ...o, status: 'concluido' };
      }
      return o;
    }));
  };

  const reviewOrder = (orderId: string, stars: number, comment: string) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          rating: {
            stars,
            comment,
            createdAt: 'Hoje'
          }
        };
      }
      return o;
    }));

    // If Carlos was the pro
    if (order.unlockedByPros.includes(currentPro.id)) {
      setCurrentPro(prev => ({
        ...prev,
        completedJobsCount: prev.completedJobsCount + 1,
        reviewCount: prev.reviewCount + 1,
        rating: Number(((prev.rating * prev.reviewCount + stars) / (prev.reviewCount + 1)).toFixed(1))
      }));
    }
  };

  const sendChatMessage = (orderId: string, text: string) => {
    if (!text.trim()) return;

    const newMessage: ChatMessage = {
      id: 'msg-' + Date.now(),
      orderId,
      senderId: userMode === 'client' ? clientProfile.id : currentPro.id,
      senderName: userMode === 'client' ? clientProfile.name : currentPro.name,
      senderRole: userMode,
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, newMessage]);
  };

  const rechargeCoins = (packId: string) => {
    const pack = COIN_PACKAGES.find(p => p.id === packId);
    if (!pack) return;

    const totalAdded = pack.coins + pack.bonus;
    setCurrentPro(prev => ({
      ...prev,
      coins: prev.coins + totalAdded
    }));
    return totalAdded;
  };

  const registerPro = (data: {
    name: string;
    title: string;
    category: string;
    city: string;
    state: string;
    phone: string;
    specialties: string[];
  }): ProfessionalProfile => {
    const newPro: ProfessionalProfile = {
      id: 'pro-' + Date.now(),
      name: data.name,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
      title: data.title,
      category: data.category,
      specialties: data.specialties.length > 0 ? data.specialties : ['Atendimento Rápido', 'Garantia de Qualidade'],
      bio: `Profissional verificado NinjaPRO atendendo em ${data.city} e região metropolitana. Comprometimento, ferramentas profissionais e garantia nos serviços prestados.`,
      city: data.city,
      state: data.state,
      rating: 5.0,
      reviewCount: 0,
      completedJobsCount: 0,
      coins: 25, // Bônus de boas-vindas: 25 moedas gratuitas para fechar 1 negociação!
      isVerified: true,
      phone: data.phone,
      memberSince: 'Hoje',
      responseTime: 'Instantâneo'
    };

    setCurrentPro(newPro);
    setUserMode('pro');
    return newPro;
  };

  const resetToWelcomeCoins = () => {
    setCurrentPro(prev => ({
      ...prev,
      coins: 25
    }));
  };

  const openChatForOrder = (orderId: string) => {
    setActiveChatOrderId(orderId);
  };

  const closeChat = () => {
    setActiveChatOrderId(null);
  };

  const resetDemoData = () => {
    localStorage.removeItem(LOCAL_STORAGE_PREFIX + 'orders');
    localStorage.removeItem(LOCAL_STORAGE_PREFIX + 'quotes');
    localStorage.removeItem(LOCAL_STORAGE_PREFIX + 'currentPro');
    localStorage.removeItem(LOCAL_STORAGE_PREFIX + 'chatMessages');
    setOrders(INITIAL_ORDERS);
    setQuotes(INITIAL_QUOTES);
    setCurrentPro(CURRENT_NINJA_PRO);
    setChatMessages(INITIAL_CHAT_MESSAGES);
    setActiveChatOrderId(null);
    setActiveOrderForQuote(null);
  };

  return (
    <NinjaContext.Provider
      value={{
        userMode,
        setUserMode,
        orders,
        quotes,
        currentPro,
        clientProfile,
        chatMessages,
        createOrder,
        unlockLead,
        submitQuote,
        acceptQuote,
        completeOrder,
        reviewOrder,
        sendChatMessage,
        rechargeCoins,
        registerPro,
        resetToWelcomeCoins,
        openChatForOrder,
        closeChat,
        activeChatOrderId,
        activeOrderForQuote,
        setActiveOrderForQuote,
        resetDemoData
      }}
    >
      {children}
    </NinjaContext.Provider>
  );
};

export const useNinja = () => {
  const context = useContext(NinjaContext);
  if (!context) {
    throw new Error('useNinja must be used within a NinjaProvider');
  }
  return context;
};
